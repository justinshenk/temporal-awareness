#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"

cd "$ROOT"

# Three build variants share the same source. main.tex uses
#   \providecommand{\neuripsmode}{preprint}
#   \usepackage[\neuripsmode]{neurips_2026}
# so we can override the option from the command line via `\def`.
#
# review.pdf       : anonymous review build  (option: main)
# preprint.pdf     : preprint with author block (option: preprint, default)
# camera_ready.pdf : final camera-ready build (option: main, final)
#
# Watch mode (`./build.sh watch`) keeps latexmk live-rebuilding the preprint
# variant so iteration stays fast; the other two variants are built only by
# the default one-shot pipeline.

MODE="${1:-once}"

PDFLATEX_BIN='pdflatex -interaction=nonstopmode -halt-on-error -synctex=1 -file-line-error'
COMMON=(-pdf -outdir="$OUT" -silent)

build_variant() {
  local name="$1"          # review | preprint | camera_ready
  local override="$2"      # latex code defining \neuripsmode (empty = default)
  local jobname="$name"

  # latexmk + pdflatex via -jobname=$jobname; -pdflatex carries the
  # \def\neuripsmode{...} preamble injection. We also forward
  # -output-directory so all aux files land in $OUT (latexmk's -outdir
  # is just metadata for it; the actual pdflatex invocation needs the
  # flag explicitly because we're overriding the command).
  local pdflatex_cmd
  if [[ -n "$override" ]]; then
    pdflatex_cmd="$PDFLATEX_BIN -output-directory=$OUT -jobname=$jobname \"$override\\input{%S}\""
  else
    pdflatex_cmd="$PDFLATEX_BIN -output-directory=$OUT -jobname=$jobname %S"
  fi

  echo "==> Building $name.pdf"
  latexmk "${COMMON[@]}" -jobname="$jobname" -pdflatex="$pdflatex_cmd" main.tex

  # Compress with Ghostscript (prepress = 300 dpi, minimal quality loss).
  if command -v gs &>/dev/null; then
    gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/prepress \
       -dNOPAUSE -dBATCH -dQUIET \
       -sOutputFile="$OUT/${name}_light.pdf" "$OUT/${name}.pdf"
    local main_kb light_kb
    main_kb=$(( $(stat -f%z "$OUT/${name}.pdf") / 1024 ))
    light_kb=$(( $(stat -f%z "$OUT/${name}_light.pdf") / 1024 ))
    echo "    $name: ${main_kb}K -> ${light_kb}K ($(( 100 - light_kb * 100 / main_kb ))% reduction)"
    # Replace the heavy file with the compressed one for downstream consumers.
    mv "$OUT/${name}_light.pdf" "$OUT/${name}.pdf"
  else
    echo "    Warning: gs not found, skipping compression (brew install ghostscript)"
  fi
}

if [[ "$MODE" == "watch" ]]; then
  exec latexmk "${COMMON[@]}" -jobname=preprint \
    -pdflatex="$PDFLATEX_BIN -jobname=preprint %S" \
    -pvc -view=none main.tex
fi

# `bash build.sh review` builds ONLY the review variant (fast iteration).
if [[ "$MODE" == "review" ]]; then
  build_variant review '\def\neuripsmode{main}'
  echo
  echo "Built: $OUT/review.pdf (review-only mode)"
  exit 0
fi

# `bash build.sh blackbox` builds the ACL variant (blackbox.tex).
# Auto-fetches acl.sty / acl_natbib.bst from acl-org/acl-style-files when missing.
if [[ "$MODE" == "blackbox" ]]; then
  if [[ ! -f acl.sty ]]; then
    echo "==> Fetching acl.sty"
    curl -fsSL -o acl.sty https://raw.githubusercontent.com/acl-org/acl-style-files/master/acl.sty
  fi
  if [[ ! -f acl_natbib.bst ]]; then
    echo "==> Fetching acl_natbib.bst"
    curl -fsSL -o acl_natbib.bst https://raw.githubusercontent.com/acl-org/acl-style-files/master/acl_natbib.bst
  fi

  echo "==> Building blackbox.pdf (ACL variant)"
  latexmk -pdf -outdir="$OUT" -silent -jobname=blackbox \
    -pdflatex="$PDFLATEX_BIN -output-directory=$OUT -jobname=blackbox %S" \
    blackbox.tex

  if command -v gs &>/dev/null; then
    gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/prepress \
       -dNOPAUSE -dBATCH -dQUIET \
       -sOutputFile="$OUT/blackbox_light.pdf" "$OUT/blackbox.pdf"
    main_kb=$(( $(stat -f%z "$OUT/blackbox.pdf") / 1024 ))
    light_kb=$(( $(stat -f%z "$OUT/blackbox_light.pdf") / 1024 ))
    echo "    blackbox: ${main_kb}K -> ${light_kb}K ($(( 100 - light_kb * 100 / main_kb ))% reduction)"
    mv "$OUT/blackbox_light.pdf" "$OUT/blackbox.pdf"
  fi

  echo
  echo "Built: $OUT/blackbox.pdf (ACL variant)"
  exit 0
fi

build_variant review       '\def\neuripsmode{main}'
build_variant preprint     ''
build_variant camera_ready '\def\neuripsmode{main,final}'

# Keep `out/main.pdf` and `out/light.pdf` for backwards compatibility with
# any external script that still references those names. main.pdf is the
# uncompressed preprint variant (matches the historical behavior).
ln -sf preprint.pdf "$OUT/main.pdf" 2>/dev/null || cp -f "$OUT/preprint.pdf" "$OUT/main.pdf"
cp -f "$OUT/preprint.pdf" "$OUT/light.pdf"

# Deploy the public preprint to the personal site if the destination exists.
DEST="$HOME/work/unrulyabstractions.github.io/pdfs/temporalpref.pdf"
if [[ -d "$(dirname "$DEST")" ]]; then
  cp "$OUT/preprint.pdf" "$DEST"
  echo "Deployed: $OUT/preprint.pdf -> $DEST"
fi

echo
echo "Built: $OUT/review.pdf, $OUT/preprint.pdf, $OUT/camera_ready.pdf"
