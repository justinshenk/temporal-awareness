#!/usr/bin/env python3
"""Linear decodability of temporal preference against fractional depth.

One line per model, read from the per-layer probe CSVs in
out/hf_new/probing/turn_preference/. The shuffled-label control is drawn as a
single grey band because it sits at chance in every model and every layer.
The shaded blue span is the causal attention band from the patching sweep.

Output: images/localize/probe_across_models.pdf (vector).
"""
from pathlib import Path
import csv
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

REPO = Path(__file__).resolve().parent.parent.parent
SRC = REPO / "out" / "hf_new" / "probing" / "turn_preference"

INK, MUTED, GRID = "#1a1a19", "#55544f", "#dcdbd6"
BAND = "#2a78d6"
MODELS = [
    ("qwen3_4b_instruct",       "Qwen3 4B-Inst",  "#2a78d6", "-"),
    ("llama31_8b_instruct",     "Llama-3.1 8B",   "#eb6834", (0, (5, 1.6))),
    ("gemma2_9b_it",            "Gemma-2 9B",     "#4a3aa7", (0, (1.6, 1.4))),
    ("mistral_7b_instruct_v03", "Mistral 7B",     "#1f8a6d", (0, (5, 1.4, 1.4, 1.4))),
]
CAUSAL_LO, CAUSAL_HI = 0.63, 0.69      # attention peak IQR from the patching sweep

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"],
                     "font.size": 8.0, "pdf.fonttype": 42})

# two panels sharing x: the plateau on top, the shuffled control below, so the
# empty middle of the accuracy range is not paid for in page height
fig, (ax, axc) = plt.subplots(
    2, 1, figsize=(5.85, 2.55), sharex=True,
    gridspec_kw={"height_ratios": [3.4, 1.0], "hspace": 0.13})

for a in (ax, axc):
    a.axvspan(CAUSAL_LO, CAUSAL_HI, color=BAND, alpha=0.09, lw=0, zorder=0)

shuffled, ends = [], []
for key, label, color, dash in MODELS:
    meta = json.loads((SRC / f"{key}_meta.json").read_text())
    denom = meta["n_layers"] - 1
    xs, ys = [], []
    with (SRC / f"{key}.csv").open() as f:
        for row in csv.DictReader(f):
            xs.append(int(row["layer"]) / denom)
            ys.append(float(row["acc"]))
            shuffled.append(float(row["acc_shuffled"]))
    ax.plot(xs, ys, ls=dash, color=color, lw=1.5, zorder=4, solid_capstyle="round")
    ends.append([ys[-1], label, color])

# push the direct labels apart so none of them collide
ends.sort(key=lambda e: -e[0])
MINGAP = 0.021
for i in range(1, len(ends)):
    if ends[i - 1][0] - ends[i][0] < MINGAP:
        ends[i][0] = ends[i - 1][0] - MINGAP
for yy, label, color in ends:
    ax.text(1.025, yy, label, color=color, fontsize=7.2, va="center", ha="left")

lo, hi = min(shuffled), max(shuffled)
axc.axhspan(lo, hi, color=MUTED, alpha=0.16, lw=0, zorder=1)
axc.text(0.012, (lo + hi) / 2, "shuffled labels", fontsize=6.9, color=MUTED,
         va="center", ha="left")

ax.set_xlim(-0.02, 1.24)
ax.set_ylim(0.815, 0.995)
ax.set_yticks([0.85, 0.90, 0.95])
axc.set_ylim(lo - 0.012, hi + 0.012)
axc.set_yticks([0.50])
axc.set_xticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
axc.set_xlabel("Fractional depth  (layer / total layers)", fontsize=8.2, color=INK)
ax.set_ylabel("Probe accuracy", fontsize=8.2, color=INK)

for a in (ax, axc):
    a.grid(True, color=GRID, lw=0.6)
    a.set_axisbelow(True)
    for sp in ("top", "right"):
        a.spines[sp].set_visible(False)
    for sp in ("bottom", "left"):
        a.spines[sp].set_color(GRID)
    a.tick_params(colors=MUTED, labelsize=7.4, length=0)
ax.spines["bottom"].set_visible(False)
axc.text((CAUSAL_LO + CAUSAL_HI) / 2, lo - 0.009, "causal band", ha="center",
         va="bottom", fontsize=7.0, color=BAND)

out = Path(__file__).resolve().parent.parent / "images" / "localize" / "probe_across_models.pdf"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, bbox_inches="tight")
print(f"wrote {out}")
for key, label, *_ in MODELS:
    m = json.loads((SRC / f"{key}_meta.json").read_text())
    print(f"   {label:16s} best frac={m['best_layer']/(m['n_layers']-1):.3f} "
          f"acc={m['best_acc']:.3f} transfer={m['best_layer_transfer_acc']:.3f}")
