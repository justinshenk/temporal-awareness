#!/usr/bin/env python3
"""Where the causal peak sits, per model and per prompt condition.

One row per run, ordered by model size. On each row the attention peak and the
MLP peak are drawn twice, once for prompts that state a horizon and once for
prompts that state none, joined by a hairline. A short line means the site does
not depend on the prompt. Faint marks are ranks 2 to 5. Every row label carries
its prompt theme in a second font and colour.

The condition split comes from both_horizon / neither_horizon in each pair's
contrastive_preference.json, and the per-condition aggregate is built with
CoarseActPatchAggregatedResults.filter_by_pairs.

Output: images/localize/depth_across_models.pdf (vector).
"""
from pathlib import Path
import json
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

REPO = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO))
from src.activation_patching.coarse.coarse_results import (  # noqa: E402
    CoarseActPatchAggregatedResults as Coarse,
)

ATTN, MLP, PROBE = "#2a78d6", "#eb6834", "#4a3aa7"
INK, MUTED, GRID = "#1a1a19", "#55544f", "#dcdbd6"
# Theme label colour by prompt setting: highly-formatted parametric themes in
# teal, the classification set in plum, the minimally-framed set in amber.
THEME_C = {"classification": "#9c4a72", "minimally framed": "#a2661c"}
THEME_DEFAULT = "#3b7f7a"
TOPK, MIN_PAIRS = 5, 5

# (name, theme, size_b, run_dir) for the patched Qwen sweeps.
RUNS = [
    ("Qwen3 0.6B",         "investment", 0.6,  "investment_qwen3_0.6b"),
    ("Qwen3 1.7B",         "investment", 1.7,  "investment_qwen3_1.7b"),
    ("Qwen3 4B",           "investment", 4.0,  "investment_qwen3_4b"),
    ("Qwen3 4B-Inst-2507", "investment", 4.0,  "investment"),
    ("Qwen3 8B",           "investment", 8.0,  "investment_qwen3_8b"),
    ("Qwen3 14B",          "investment", 14.0, "investment_qwen3_14b"),
    ("Qwen3.5 0.8B",       "investment", 0.8,  "investment_qwen3.5_0.8b"),
    ("Qwen3.5 2B",         "investment", 2.0,  "investment_qwen3.5_2b"),
    ("Qwen3.5 4B",         "investment", 4.0,  "investment_qwen3.5_4b"),
]
GEMMA = ("Gemma-2 9B-it", "investment", 9.0, [28, 26, 25], [38, 39, 26], 41)

# The replication sweeps patched three further families over every layer, on the
# horizon-stated pairs, ranked by mean recovery plus disruption as in the
# cross-model table. Layer lists are ranks 1 to 5; the last field is the top
# layer index (n_layers - 1).
REPLICATION = [
    ("Gemma-2 9B-it", "climate, all layers", 9.0,
     [25, 26, 23, 28, 29], [26, 39, 32, 38, 37], 41),
    ("Llama-3.1 8B", "health", 8.0,
     [17, 14, 15, 18, 13], [29, 26, 20, 27, 18], 31),
    ("Mistral-7B v0.3", "education", 7.0,
     [16, 19, 15, 18, 31], [31, 29, 30, 28, 27], 31),
]

# The classification prompts were patched separately on the target model, at the
# END token, and reported per layer in the submission. Attention writers rank
# L24, L26, L30, L21, L33; the MLP writer band is L27, L28, L31.
CLASSIF = ("Qwen3 4B-Inst-2507", "classification", 4.0,
           [24, 26, 30, 21, 33], [27, 28, 31], 35)

# The minimally-framed prompts were localized by gradient attribution rather
# than by patching. Attention mass peaks at L24 and is enriched over L21-L26;
# MLP mass sits in L31-L35.
IMPLICIT = ("Qwen3 4B-Inst-2507", "minimally framed", 4.0,
            [24, 22, 23, 26, 21], [31, 32, 33, 34, 35], 35)

# Where a linear probe reads the preference best, from the per-layer sweeps.
# Keyed by (name, theme); only rows we ran a probe on carry a mark. The probe
# is per model, so both Gemma rows carry the same mark.
PROBE_PEAK = {
    ("Qwen3 4B-Inst-2507", "investment"): 17 / 35,
    ("Gemma-2 9B-it", "investment"): 23 / 41,
    ("Gemma-2 9B-it", "climate, all layers"): 23 / 41,
    ("Llama-3.1 8B", "health"): 29 / 31,
    ("Mistral-7B v0.3", "education"): 14 / 31,
}


def pair_conditions(run):
    root = REPO / "out" / "experiments" / run / "pairs"
    groups = {"horizon": [], "latent": []}
    if not root.is_dir():
        return groups
    for d in root.iterdir():
        f = d / "contrastive_preference.json"
        if not (f.is_file() and d.name.startswith("pair_")):
            continue
        j = json.loads(f.read_text())
        idx = int(d.name.split("_")[1])
        if j.get("both_horizon"):
            groups["horizon"].append(idx)
        elif j.get("neither_horizon"):
            groups["latent"].append(idx)
    return groups


def top_depths(run, component, pairs=None, k=TOPK):
    path = REPO / "out" / "experiments" / run / "aggregated" / "coarse" / f"{component}.json"
    if not path.exists():
        return []
    agg = Coarse.from_json(path)
    denom = max(agg.get_mean_layer_results().keys())    # layer / (n_layers - 1)
    if pairs is not None:
        agg = agg.filter_by_pairs(pairs)
    sweep = agg.get_mean_layer_results()
    if not sweep:
        return []
    ranked = sorted(sweep.keys(), key=lambda L: -(sweep[L].recovery or 0.0))[:k]
    return [L / denom for L in ranked]


rows = []
for name, theme, size, run in RUNS:
    groups = pair_conditions(run)
    per_cond = {}
    for key in ("horizon", "latent"):
        pairs = groups.get(key, [])
        if len(pairs) >= MIN_PAIRS:
            per_cond[key] = {"attn": top_depths(run, "attn_out", pairs),
                             "mlp": top_depths(run, "mlp_out", pairs)}
    rows.append((name, theme, size, per_cond))
for name, theme, size, ga, gm, gn in [GEMMA, *REPLICATION, CLASSIF, IMPLICIT]:
    rows.append((name, theme, size, {"horizon": {"attn": [L / gn for L in ga],
                                                 "mlp": [L / gn for L in gm]}}))

# Order by model size. Within a size, keep the target model's three prompt sets
# together, in the order parametric, classification, minimally framed.
SUBORDER = {"investment": 0, "classification": 1, "minimally framed": 2}
rows.sort(key=lambda r: (r[2], r[0], SUBORDER.get(r[1], 0)))

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"],
                     "font.size": 8.0, "pdf.fonttype": 42})

ypos, y = {}, 0.0
prev_size = None
for name, theme, size, _ in reversed(rows):
    if prev_size is not None and size != prev_size:
        y += 0.40
    ypos[(name, theme)] = y
    prev_size = size
    y += 1.0
YTOP = y - 0.40

fig, ax = plt.subplots(figsize=(5.85, 0.26 * len(rows) + 1.0))

peaks = sorted(c["attn"][0] for _, _, _, pc in rows for c in pc.values() if c["attn"])
q1, q3 = peaks[len(peaks) // 4], peaks[(3 * len(peaks)) // 4]
ax.axvspan(q1, q3, color=ATTN, alpha=0.09, lw=0, zorder=0)

OFFSET = {"attn": 0.16, "mlp": -0.16}
COLOR = {"attn": ATTN, "mlp": MLP}
MARKER = {"attn": "o", "mlp": "s"}

for name, theme, _, per_cond in rows:
    yy = ypos[(name, theme)]
    probe = PROBE_PEAK.get((name, theme))
    if probe is not None:
        ax.plot(probe, yy, "v", ms=6.0, color=PROBE, mec="white", mew=0.9, zorder=7)
    for comp in ("attn", "mlp"):
        ry, col = yy + OFFSET[comp], COLOR[comp]
        for d in per_cond.get("horizon", {}).get(comp, [])[1:]:
            ax.plot(d, ry, MARKER[comp], ms=3.0, color=col, alpha=0.17,
                    mec="none", zorder=2)
        pk = {k: v[comp][0] for k, v in per_cond.items() if v[comp]}
        if len(pk) == 2:
            ax.plot([pk["horizon"], pk["latent"]], [ry, ry], "-", color=col,
                    lw=1.1, alpha=0.55, zorder=3, solid_capstyle="round")
        if "latent" in pk:
            ax.plot(pk["latent"], ry, MARKER[comp], ms=8.0, mfc="white",
                    mec=col, mew=1.4, zorder=5)
        if "horizon" in pk:
            ax.plot(pk["horizon"], ry, MARKER[comp], ms=4.8, color=col,
                    mec="none", zorder=6)

# Row labels: model name in the body serif, theme in a second font and colour.
ax.set_yticks([ypos[(n, t)] for n, t, _, _ in rows])
ax.set_yticklabels([])
ax.tick_params(axis="y", length=0)

ax.set_xlim(0.40, 1.03)
ax.set_xticks([0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
ax.set_ylim(-0.55, YTOP + 0.48)
ax.set_xlabel("Fractional depth  (layer / total layers)", fontsize=8.2, color=INK)
ax.xaxis.grid(True, color=GRID, lw=0.6)
ax.set_axisbelow(True)
for sp in ("top", "right", "left"):
    ax.spines[sp].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", colors=MUTED, labelsize=7.4)
ax.legend(handles=[
    Line2D([], [], marker="o", ls="", ms=6.0, color=ATTN, mec="none",
           label="attention"),
    Line2D([], [], marker="s", ls="", ms=5.6, color=MLP, mec="none",
           label="MLP"),
    Line2D([], [], marker="v", ls="", ms=6.0, color=PROBE, mec="white", mew=0.9,
           label="probe peak"),
    Line2D([], [], marker="o", ls="", ms=7.6, mfc="white", mec=MUTED, mew=1.3,
           label="ring = horizon field left null"),
], loc="lower right", bbox_to_anchor=(1.0, 1.004), ncol=4, frameon=False,
   fontsize=7.0, handletextpad=0.3, columnspacing=1.0, borderaxespad=0.0)

fig.tight_layout()
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
ax_w = ax.get_window_extent(renderer).width
trans = ax.get_yaxis_transform()
for name, theme, _, _ in rows:
    yy = ypos[(name, theme)]
    t = ax.text(-0.015, yy, f"({theme})", transform=trans, ha="right",
                va="center", fontsize=6.6, style="italic",
                family="DejaVu Sans", color=THEME_C.get(theme, THEME_DEFAULT))
    w = t.get_window_extent(renderer).width / ax_w
    ax.text(-0.015 - w - 0.010, yy, name, transform=trans, ha="right",
            va="center", fontsize=7.5, color=MUTED)

out = Path(__file__).resolve().parent.parent / "images" / "localize" / "depth_across_models.pdf"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, bbox_inches="tight")
print(f"wrote {out}")
print(f"attention peak IQR = {q1:.2f}-{q3:.2f}   rows = {len(rows)}")
