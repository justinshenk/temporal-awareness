#!/usr/bin/env python3
"""Per-model behavioural summary: coherence and choice stability.

Metrics are computed with the definitions in
scripts/intertemporal/coherent_behavior_viz.py, imported rather than
reimplemented, over out/behavioral/investment_behave_all/responses.json
(the 30-model run; the _full run has only 4 and must not be used).

  Temporal reasoning : % of choices in the 1-5y reasoning zone that match the
                       rational rule (only the 6-month option can deliver).
  Order stability    : % of matched pairs whose choice survives swapping the
                       presentation order of the two options.
  Label stability    : % of matched pairs whose choice survives relabelling
                       a)/b) as x)/y).

Output: images/characterize/behavioral_summary.pdf (vector).
"""
from pathlib import Path
import json, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

REPO = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO / "scripts" / "intertemporal"))
import coherent_behavior_viz as V  # noqa: E402

RUN = REPO / "out" / "behavioral" / "investment_behave_all"
data = json.load(open(RUN / "responses.json"))

# Models run separately on the same 960-prompt grid, merged in by sample_idx so
# every metric below is computed by the same code over the same items.
EXTRA = {"coh_gpt-4o-mini": "gpt-4o-mini",
         "coh_gemma2-9b": "gemma-2-9b-it",
         "coh_llama31-8b": "Llama-3.1-8B-Instruct",
         "coh_mistral-7b": "Mistral-7B-Instruct-v0.3"}
EXTRA_ROOT = REPO / "out" / "hf_new" / "behavioral" / "coherence"
for d, key in EXTRA.items():
    src = EXTRA_ROOT / d / "responses.json"
    if not src.exists():
        continue
    lut = {r["sample_idx"]: r for r in json.load(open(src))}
    for rec in data:
        add = lut.get(rec.get("sample_idx"))
        if add is None:
            continue
        rec[f"{key}_response"] = add.get(f"{key}_response")
        rec[f"{key}_choice"] = add.get(f"{key}_choice")

# The registry drives detection, so newly run models need an entry to appear.
_EXTRA_SPECS = [
    V.ModelSpec("gemma-2-9b-it", "Gemma-2-9B", "Gemma-2-9B", "gemma", 9.0, "instruct", "#8C6D31"),
    V.ModelSpec("Llama-3.1-8B-Instruct", "Llama-3.1-8B", "Llama-3.1-8B", "llama", 8.0, "instruct", "#B15928"),
    V.ModelSpec("gpt-4o-mini", "GPT-4o Mini", "GPT-4o-mini", "openai", None, "api", "#6A3D9A"),
    V.ModelSpec("Mistral-7B-Instruct-v0.3", "Mistral-7B", "Mistral-7B", "mistral", 7.0, "instruct", "#33A02C"),
]
for spec in _EXTRA_SPECS:
    if spec.key not in V._BY_KEY:
        V.MODEL_REGISTRY.append(spec)
        V._BY_KEY[spec.key] = spec

# The panel already carries quantized variants. Label them, so a full-precision
# row and its 4-bit counterpart are never read as the same model.
for i, spec in enumerate(V.MODEL_REGISTRY):
    if "4bit" in spec.key.lower() and "4-bit" not in spec.short:
        relabelled = type(spec)(spec.key, spec.short + " (4-bit)", spec.compact,
                                spec.family, spec.size_b, spec.variant, spec.color)
        V.MODEL_REGISTRY[i] = relabelled
        V._BY_KEY[spec.key] = relabelled

V._add_thm(data)                       # the module's own preprocessing
present = V._detect_models(data)       # and its own model detection

def order_stability(spec):
    row = V._order_stability_matrix(data, [spec])[0]
    return float(np.nanmean(row))

def label_stability(spec):
    vals = []
    for h in V.HORIZON_MONTHS_ORDER:
        subset = [d for d in data if d["thm"] == h]
        groups = {}
        for d in subset:
            ls = V._get_label_style(d)
            key = (d["long_term_reward"], d["context_id"], d["short_term_first"])
            groups.setdefault(key, {})[ls] = V._get_choice(d, spec.key)
        tot = st = 0
        for _, styles in groups.items():
            if "ab" in styles and "xy" in styles:
                tot += 1
                st += (styles["ab"] == styles["xy"])
        if tot:
            vals.append(100 * st / tot)
    return float(np.nanmean(vals)) if vals else float("nan")

rows = []
for s in present:
    coh, n = V._rule_match_pct(data, s.key, "rational", zone_only=True)
    if not n:
        continue
    rows.append((s.short, coh,
                 order_stability(s), label_stability(s), s.key, s.size_b))
rows.sort(key=lambda r: (r[5] is None, r[5]))   # ascending size, API models last

CAMPAIGN = {"Qwen3-4B-Instruct-2507", "Llama-3.1-8B-Instruct", "gemma-2-9b-it",
            "Mistral-7B-Instruct-v0.3", "Qwen3.5-4B"}
labels = [r[0] for r in rows]
M = np.array([[r[1], r[2], r[3]] for r in rows], dtype=float)
cols = ["Temporal\nreasoning", "Order\nstability", "Label\nstability"]

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"],
                     "font.size": 8.5, "pdf.fonttype": 42})

C_REASON, C_ORDER, C_LABEL = "#2a78d6", "#eb6834", "#4a3aa7"   # validated slots 1,2,7
GRID, INK, MUTED = "#dcdbd6", "#1a1a19", "#55544f"

half = (len(rows) + 1) // 2
fig, axes = plt.subplots(1, 2, figsize=(7.0, 0.163 * half + 0.80), sharex=True)

for panel, ax in enumerate(axes):
    sl = slice(0, half) if panel == 0 else slice(half, len(rows))
    rp = rows[sl]
    ys = np.arange(len(rp))[::-1]          # best at top
    ax.axvspan(90, 100, color=C_REASON, alpha=0.06, lw=0)
    for y, r in zip(ys, rp):
        ax.plot([min(r[1], r[2], r[3]), max(r[1], r[2], r[3])], [y, y],
                color=GRID, lw=1.0, zorder=1)
        ax.plot(r[1], y, "o", ms=5.4, color=C_REASON, mec="white", mew=0.9, zorder=3)
        ax.plot(r[2], y, "s", ms=5.0, color=C_ORDER, mec="white", mew=0.9, zorder=3)
        ax.plot(r[3], y, "^", ms=5.4, color=C_LABEL, mec="white", mew=0.9, zorder=3)
    ax.set_yticks(ys)
    ax.set_yticklabels([r[0] for r in rp], fontsize=6.6)
    for t, r in zip(ax.get_yticklabels(), rp):
        if r[4] in CAMPAIGN:
            t.set_fontweight("bold"); t.set_color("#c2185b")
        else:
            t.set_color(MUTED)
    ax.set_xlim(0, 104)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_ylim(-0.7, len(rp) - 0.3)
    ax.xaxis.grid(True, color=GRID, lw=0.6)
    ax.yaxis.grid(True, color="#eeedea", lw=0.5)
    ax.set_axisbelow(True)
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(axis="y", length=0)
    ax.tick_params(axis="x", colors=MUTED, labelsize=7.6)
    ax.set_xlabel("percent", fontsize=8, color=INK)

axes[0].legend(handles=[
    Line2D([], [], marker="o", ls="", ms=6.4, color=C_REASON, mec="white", mew=1.1, label="temporal reasoning"),
    Line2D([], [], marker="s", ls="", ms=6.0, color=C_ORDER,  mec="white", mew=1.1, label="order stability"),
    Line2D([], [], marker="^", ls="", ms=6.4, color=C_LABEL,  mec="white", mew=1.1, label="label stability"),
], loc="lower left", bbox_to_anchor=(0.0, 1.005), ncol=3, frameon=False,
   fontsize=7.8, handletextpad=0.35, columnspacing=1.2, borderaxespad=0.0)

fig.tight_layout()
out = Path(__file__).resolve().parent.parent / "images" / "characterize" / "behavioral_summary.pdf"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, bbox_inches="tight")
print(f"wrote {out}  ({len(rows)} models)")
