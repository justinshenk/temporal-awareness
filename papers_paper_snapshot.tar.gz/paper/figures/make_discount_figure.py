#!/usr/bin/env python3
"""Hyperbolic discount rate against delay, from the titrated indifference sweep.

Read from out/hf_new/behavioral/extreme_discount/extreme_discount_summary.csv.
Cells where the model never crossed indifference inside the cap carry a lower
bound on k rather than a value, and we draw those as open markers so the two
are never confused.

Output: images/characterize/extreme_discount.pdf (vector).
"""
from pathlib import Path
import csv
from collections import defaultdict
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

REPO = Path(__file__).resolve().parent.parent.parent
SRC = REPO / "out" / "hf_new" / "behavioral" / "extreme_discount" / "extreme_discount_summary.csv"

INK, MUTED, GRID = "#1a1a19", "#55544f", "#dcdbd6"
SHORT = {"Qwen/Qwen3-4B-Instruct-2507": "Qwen3 4B-Inst",
         "meta-llama/Llama-3.1-8B-Instruct": "Llama-3.1 8B"}
COLOR = {"Qwen3 4B-Inst": "#2a78d6", "Llama-3.1 8B": "#eb6834"}
DASH = {50: (0, (1.6, 1.4)), 500: (0, (5, 1.6)), 5000: "-"}
K_HIGH = 0.5      # the study's own threshold for an extreme rate

rows = defaultdict(list)
with SRC.open() as f:
    for r in csv.DictReader(f):
        m = SHORT.get(r["model"], r["model"])
        k = r["k"] or r["k_lower_bound"]
        if not k:
            continue
        rows[(m, int(r["R"]))].append(
            (float(r["delay_years"]), float(k), r["status"] == "no_boundary"))

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"],
                     "font.size": 8.0, "pdf.fonttype": 42})
fig, ax = plt.subplots(figsize=(5.85, 2.5))

ax.axhspan(K_HIGH, 1e5, color="#eb6834", alpha=0.07, lw=0, zorder=0)
ax.text(26, 2.2e4, "extreme rate", fontsize=6.9, color="#b04d22",
        va="center", ha="right")

for (m, R), pts in sorted(rows.items()):
    pts.sort()
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    ax.plot(xs, ys, ls=DASH[R], color=COLOR[m], lw=1.4, zorder=3)
    for x, y, bound in pts:
        if bound:
            ax.plot(x, y, "o", ms=5.0, mfc="white", mec=COLOR[m], mew=1.3, zorder=4)
        else:
            ax.plot(x, y, "o", ms=4.0, color=COLOR[m], mec="none", zorder=5)

ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("Delay (years)", fontsize=8.2, color=INK)
ax.set_ylabel("Hyperbolic $k$", fontsize=8.2, color=INK)
ax.grid(True, color=GRID, lw=0.6)
ax.set_axisbelow(True)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)
for sp in ("bottom", "left"):
    ax.spines[sp].set_color(GRID)
ax.tick_params(colors=MUTED, labelsize=7.4, length=0)

ax.legend(handles=[
    Line2D([], [], color=COLOR["Qwen3 4B-Inst"], lw=1.4, label="Qwen3 4B-Inst"),
    Line2D([], [], color=COLOR["Llama-3.1 8B"], lw=1.4, label="Llama-3.1 8B"),
    Line2D([], [], color=MUTED, lw=1.2, ls=DASH[50], label="near reward 50"),
    Line2D([], [], color=MUTED, lw=1.2, ls=DASH[500], label="500"),
    Line2D([], [], color=MUTED, lw=1.2, ls=DASH[5000], label="5000"),
    Line2D([], [], marker="o", ls="", ms=5.0, mfc="white", mec=MUTED, mew=1.3,
           label="open = lower bound, no indifference point"),
], loc="lower left", bbox_to_anchor=(0.0, 1.004), ncol=3, frameon=False,
   fontsize=6.8, handletextpad=0.35, columnspacing=1.0, borderaxespad=0.0)

fig.tight_layout()
out = Path(__file__).resolve().parent.parent / "images" / "characterize" / "extreme_discount.pdf"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, bbox_inches="tight")
print(f"wrote {out}")
for (m, R), pts in sorted(rows.items()):
    nb = sum(1 for _, _, b in pts if b)
    print(f"   {m:16s} R={R:5d}  cells={len(pts)}  no-boundary={nb}  "
          f"k range {min(p[1] for p in pts):.4g}..{max(p[1] for p in pts):.4g}")
