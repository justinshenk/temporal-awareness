# Temporal Subgraphs and their Functions in a Large Language Model

NeurIPS 2026 submission.

## Building

```bash
./build.sh        # One-shot build → out/main.pdf (also copies to website)
./build.sh watch   # Continuous rebuild on save (latexmk -pvc)
```

Requires TeX Live 2025+ with `scheme-full`.

## Repository Structure

```
├── main.tex                  # Document root
├── abstract.tex              # Abstract
├── paperdefs.tex             # Package imports
├── paperutils.sty            # Custom commands (\partpage, \figrow, etc.)
├── build.sh                  # Build script
├── references.bib            # Bibliography
├── checklist.tex             # NeurIPS checklist
│
├── sections/                 # Main paper body
│   ├── introduction.tex
│   ├── background.tex
│   ├── related_work.tex
│   ├── methodology.tex
│   ├── experimental_setup.tex
│   ├── results.tex
│   ├── discussion.tex
│   ├── limitations.tex
│   └── conclusion.tex
│
├── appendix/                 # Appendices (A–N), organized by part
│   ├── guide.tex             # Guide to the Appendices (unnumbered)
│   ├── preliminaries/        # Part 0: Experimental scaffolding
│   │   ├── notation.tex          # App A: Notation & key concepts
│   │   ├── prompts.tex           # App B: Prompting settings & datasets
│   │   ├── attributional_contrastive_methods.tex # App C: EAP-IG methodology
│   │   ├── causal_parametric_methods.tex  # App D: Activation patching methodology
│   │   ├── behavioral_temporal_discount_methods.tex  # App E: Kirby MCQ-27 methodology
│   │   ├── contrastive_probing_linear_methods.tex     # App F: Probing methodology
│   │   └── contrastive_steering_methods.tex    # App G: CAA contrastive steering methodology
│   ├── localize/             # Part 1: Where is temporal preference?
│   │   ├── attributional_contrastive.tex  # App H: EAP-IG attribution results
│   │   ├── causal_parametric.tex         # App I: Activation patching results
│   │   └── contrastive_probing_linear.tex       # App J: Probing results
│   ├── characterize/         # Part 2: What does temporal preference look like?
│   │   ├── parametric_geometry.tex # App K: Parametric geometry (PCA)
│   │   └── behavioral_temporal_discount.tex        # App L: Behavioral analysis results
│   ├── intervene/            # Part 3: Could we control temporal preference?
│   │   └── contrastive_steering.tex  # App M: CAA contrastive steering results
│   └── case_studies/         # Part 4: Case studies
│       └── hf_pair.tex           # App N: Highly-formatted pair case study
│
├── images/                   # Figures, organized to mirror appendix/
│   ├── intro/                    # Main paper intro figures
│   ├── results/                  # Main paper results figures
│   ├── preliminaries/            # Part 0 figures
│   │   └── attributional_contrastive/  # Prompt structure diagram
│   ├── localize/                 # Part 1 figures
│   │   ├── attributional_contrastive/ # Attribution histograms, heatmaps, etc.
│   │   ├── causal_parametric/         # Layer sweeps, component interactions
│   │   └── contrastive_probing/       # Probe accuracy, PCA, cross-dataset
│   ├── characterize/             # Part 2 figures
│   │   ├── parametric_geometry/        # PCA scatter plots (by_layer/, by_position/)
│   │   └── behavioral/               # Decision boundary traces
│   ├── intervene/                # Part 3 figures
│   │   └── contrastive_steering/       # (contrastive steering result plots)
│   └── case_studies/             # Part 4 figures
│       └── hf_pair/                   # Highly-formatted pair case study
│           ├── tokenization.pdf
│           ├── position_mapping.pdf
│           └── coarse_sweep/          # Layer & position sweep PDFs
│
├── figures/                  # TikZ source files for vector diagrams
│   ├── method_diagram.tex
│   ├── prompting_comparison.tex
│   ├── querying_intuition.tex
│   ├── reparametrize.tex
│   ├── temp_defs.tex
│   └── turns.tex
│
└── out/                      # Build output (gitignored)
    └── main.pdf
```

## Conventions

- **Labels**: `\label{sec:...}` for main sections, `\label{app:...}` for appendices, `\label{fig:...}` for figures, `\label{tab:...}` for tables, `\label{eq:...}` for equations.
- **References**: Always use `\ref{app:...}` instead of hardcoded appendix letters.
- **Images**: Paths mirror the appendix subfolder structure (`images/localize/attributional_contrastive/` for `appendix/localize/attributional_contrastive.tex`).
- **Part pages**: Use `\partpagecontent{Part N:}{Title}{bullet list}` for part divider pages.
- **Appendix numbering**: Auto-resets figures, tables, and equations per appendix via `\clearappnumbering`.
