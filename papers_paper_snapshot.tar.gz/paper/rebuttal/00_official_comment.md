# Official Comment (all reviewers)

<!-- POST AS: Official Comment. Readers: everyone. -->
<!-- Paste everything below the line. OpenReview renders Markdown. Limit 5000 characters. -->

**Title:** Common response: we ran the pipeline on four families and five domains

---

Every review raises scope. We ran the pipeline on three further families during the discussion period. We then narrowed the paper to the results that hold across all of them.

## What we ran during the discussion period

**Steering on four families, against a matched-norm control.**

- We inject a random direction of matched norm at the same layer and score it the same way. The steering vector has to beat an arbitrary perturbation of the same size.
- It does, in 77 of 80 sweep cells, across Qwen3-4B-Instruct-2507, Llama-3.1-8B-Instruct, gemma-2-9b-it, and Mistral-7B-Instruct-v0.3.
- The steerable layer sits near half of depth in all four models.
- We swept depths 0.50 to 0.65. The sweep bounds the band and does not find its edges.

**Geometry outside Qwen, on non-financial domains.**

- Llama-3.1-8B deciding over quality-adjusted life years.
- gemma-2-9b-it deciding over tonnes of carbon prevented.
- The turn-boundary progression appears in both, at each family's own turn tokens.

**Coherence on five models, same 960-prompt grid.**

- The Qwen anchor reproduces the submission's own value, so the instrument is sound.
- Coherence tracks neither scale nor provider. One open 9B model reaches the coherent range while several larger open models do not.
- This sharpens what the submission claimed about which models get there.

## What the submission already held

- Causal localization on nine Qwen checkpoints, 0.6B to 14B.
- Behavioral analysis across 10 families.

Both sat in the appendix, so the paper read as a single-model study. Both are now in the main text.

## One domain per model

Each model decides in a different domain, and no model and domain pair repeats.

- Qwen3-4B-Instruct-2507: investment, in dollars.
- Llama-3.1-8B: health, in quality-adjusted life years.
- Gemma-2-9B: climate, in tonnes of carbon prevented.
- Mistral-7B: education, in lifetime earnings.
- Qwen3-4B-Instruct-2507 again: startup revenue. The planned Qwen3.5-4B run is architecturally incompatible with our patching stack, so this run checks the target model on a second domain.

## What the paper now reports

Every review asked how far the results generalize. We kept the results that replicate across families. We removed the single-model material that competed with them for space.

**Localization, and what carries it.** Activation patching intervenes on the forward pass, and it is what replicates across families and scale. Three prompt sets now place the same component at the same depth on the target model: parametric prompts and classification prompts by activation patching, and minimally-framed prompts by gradient attribution. The site survives a change of cue, a change of task, and a change of framing. We claim a set of located components, and we name edge-level tracing as the next step.

**One behavioral instrument.** The coherence questionnaire runs the same grid in every model, so the rows compare directly. The human reference comparison rested on one sample and did not extend across the campaign.

## What changed in the presentation

- Main text: 7 pages.
- Appendix: three sections, down from thirty.
- Every claim now has a figure built from the data. The two localization figures are vector with labelled axes. The PCA panels are still raster and we are converting them before the camera-ready.
