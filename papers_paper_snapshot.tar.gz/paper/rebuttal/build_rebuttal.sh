#!/usr/bin/env bash
# Build rebuttal.pdf from the Markdown comment files.
#
# The Markdown files are the single source of truth. This script extracts the
# postable body of each one (everything after the first `---` rule), renders it
# with the LaTeX markdown package, and counts characters against OpenReview's
# 5000-character limit. Re-run it after any edit to a .md file.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD="$ROOT/.build"
cd "$ROOT"

# Order matters: this is the posting order.
FILES=(
  "00_official_comment.md"
  "01_replication_update.md"
  "reviewer_i7iD.md"
  "reviewer_UK5t.md"
  "reviewer_APpt.md"
  "ac_confidential.md"
)

rm -rf "$BUILD"
mkdir -p "$BUILD"

# --- Extract postable bodies and measure them -------------------------------
declare -a TITLES COUNTS SLUGS
for f in "${FILES[@]}"; do
  slug="${f%.md}"
  # Body = everything after the first line that is exactly `---`.
  awk 'found {print} /^---$/ && !found {found=1}' "$f" > "$BUILD/$slug.body.md"
  # Title = the "**Title:** ..." line, used for the section heading.
  title=$(awk '/^---$/{exit} /^\*\*Title:\*\*/{sub(/^\*\*Title:\*\* */,""); print; exit}' "$f")
  [ -z "$title" ] && title="$slug"
  count=$(wc -c < "$BUILD/$slug.body.md" | tr -d ' ')
  SLUGS+=("$slug"); TITLES+=("$title"); COUNTS+=("$count")
done

# --- Emit the wrapper -------------------------------------------------------
{
  cat <<'PREAMBLE'
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{booktabs}
\usepackage{tabularx}
\usepackage{xcolor}
\usepackage[colorlinks=true,linkcolor=black,urlcolor=blue]{hyperref}
\usepackage[pipeTables=true,tableCaptions=true,fencedCode=true,hashEnumerators=true]{markdown}
\usepackage{fancyhdr}
\usepackage{etoolbox}
\AtBeginEnvironment{tabular}{\footnotesize\setlength{\tabcolsep}{4pt}}
\setcounter{secnumdepth}{0}
\setlength{\parskip}{0.5em}
\setlength{\parindent}{0pt}
\pagestyle{fancy}
\fancyhf{}
\rhead{\small NeurIPS 2026 Submission 25332}
\lhead{\small Discussion package}
\cfoot{\thepage}
\renewcommand{\headrulewidth}{0.4pt}
\begin{document}

PREAMBLE


  for idx in "${!SLUGS[@]}"; do
    slug="${SLUGS[$idx]}"
    t=$(printf '%s' "${TITLES[$idx]}" | sed 's/&/\\&/g; s/_/\\_/g')
    echo '\clearpage'
    echo "\\section*{$((idx+1)). $t}"
    echo "\\markdownInput{$slug.body.md}"
  done

  echo '\end{document}'
} > "$BUILD/rebuttal.tex"

# --- Compile ----------------------------------------------------------------
cd "$BUILD"
for pass in 1 2; do
  lualatex -interaction=nonstopmode -halt-on-error rebuttal.tex > "pass$pass.log" 2>&1 || {
    echo "ERROR: lualatex failed on pass $pass. Last errors:" >&2
    grep -E "^!" -A4 "pass$pass.log" | head -30 >&2
    exit 1
  }
done
cd "$ROOT"
cp "$BUILD/rebuttal.pdf" "$ROOT/rebuttal.pdf"

echo "Built: $ROOT/rebuttal.pdf"
for idx in "${!SLUGS[@]}"; do
  c="${COUNTS[$idx]}"
  status="ok"
  [ "$c" -gt 5000 ] && status="OVER LIMIT"
  printf "  %-26s %5s / 5000  %s\n" "${SLUGS[$idx]}" "$c" "$status"
done
