
The presentation criticisms are correct and we concede them in full. We answer each weakness in order.

**W1. The main text is not self-contained and the appendix runs over 100 pages.**

Conceded. The main text is now 7 pages and the appendix is two sections. Definitions, method summaries, and dataset structure sit in the main text, including the passages at lines 115, 142, and 157 that deferred to the appendix.

**W2. The figures are low-resolution bitmaps.**

Conceded. The two localization figures are vector with labelled axes. The PCA panels are still raster and we are converting them before the camera-ready.

**W3. Only one model is studied.**

The submission held evidence beyond the 4B model in the appendix.

- It patched nine Qwen checkpoints from 0.6B to 14B.
- It ran the behavioral battery across 10 families.

Both are now in the main text. Figure 3 also includes `gemma-2-9b-it` from a different family, and the attention peak sits between 0.60 and 0.69 of depth in nine of the ten checkpoints. The geometry replicates on Llama and Gemma, and steering replicates on Llama, Gemma, and Mistral. Patching on Llama and Mistral is running and is not in this revision.

The Limitations section states the demonstrated scope. Mechanistic evidence covers four families across five domains plus one scale sweep. Behavioral evidence covers 10 families. Edge-level tracing remains open.

**W4. A subgraph claim requires edges.**

We agree with your definition and we took the conservative route. We no longer claim a subgraph. We claim a set of located components, and the text names edge-level tracing as the next step.

Three prompt sets now place the same component at the same depth on the target model: parametric prompts and classification prompts by activation patching, and minimally-framed prompts by gradient attribution. The site survives a change of cue, a change of task, and a change of framing. Attribution is correlational and we read it only as a second opinion on depth, never as evidence of information flow.

**W5. The coherence section seems disconnected.**

The link is the gap between representation and behavior. The geometry shows that the model represents temporal preference cleanly. The coherence section shows that the model still takes the undeliverable option about half the time in the reasoning zone. We argue for explicit control because the preference is cleanly represented and unreliably acted on. That link is now the first sentence of the section.

**W6. The introductory poem.**

Conceded. It is gone, and the space carries the definitions you asked for.

**On formatting.**

We will conform the font and the in-text citation format to the NeurIPS template and verify compliance before the camera-ready.
