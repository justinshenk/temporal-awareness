
The meta-review sets one bar. Localization and steering must replicate on a non-Qwen model or at a different scale. Both halves are now met, and we went past the bar on the family axis.

**Scale was already in the submission.** We patched nine Qwen checkpoints from 0.6B to 14B. That result sat in the appendix and is now Figure 3 in the main text.

**The non-Qwen half is met.** Localization covers ten checkpoints: nine Qwen from 0.6B to 14B across two generations, plus `gemma-2-9b-it` from a different family. The attention peak sits between 0.60 and 0.69 of depth in nine of the ten, with half inside a 0.63 to 0.69 core. The absolute layer index moves by a factor of five across that set and the fraction does not. Patching on Llama and Mistral is running and is not in this revision.

**Geometry and steering go further.** The turn-boundary geometry replicates on Llama and Gemma. Steering replicates on Llama, Gemma, and Mistral as well as Qwen. We assigned a different domain to each model, so the campaign spans five domains. The invariant we test is within-model, so it does not require crossing model with domain. Crossing them is future work.

**Steering is new, and so is its control.** The submission had no control at all. We now score every configuration against a random direction of matched norm injected at the same layer.

- The steering vector beats that control in 77 of 80 sweep cells.
- The steerable layer sits near half of depth in all four models.
- We swept depths 0.50 to 0.65. The sweep bounds that band and does not find its edges.

**On scope.** We narrowed the paper to the results that generalize. Activation patching replicates across four families and a factor of twenty in scale, and it carries the localization claim. Three prompt sets now place the same component at the same depth on the target model: parametric prompts and classification prompts by activation patching, and minimally-framed prompts by gradient attribution. The site survives a change of cue, a change of task, and a change of framing. We claim a set of located components rather than a subgraph, which settles Reviewer APpt's objection that a subgraph claim needs edges.

On the behavioral side we kept the coherence instrument. It runs the same grid in every model and yields directly comparable rows. The human reference comparison rested on a single sample and did not extend across the campaign, which settles Reviewer i7iD's question about the Kirby baseline.

**On presentation.** All three reviewers raised it and we conceded in full. The main text is 7 pages. The appendix is two sections instead of thirty. The two localization figures are vector with labelled axes. The PCA panels are still raster and we are converting them before the camera-ready.

**What remains open.** We do not trace information flow between the located components. The behavioral evidence covers 10 families while the mechanistic evidence covers four. All settings are single-turn.

We are available for follow-ups throughout the discussion period.
