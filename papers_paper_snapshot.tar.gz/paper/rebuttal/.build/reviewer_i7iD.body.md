
**Q1. Does the localization transfer to larger Qwen models or other families?**

Yes, on both axes.

Across scale, the submission already patched nine Qwen checkpoints from 0.6B to 14B. That result sat in the appendix and is now Figure 3.

Across families, Figure 3 now includes `gemma-2-9b-it`. The attention peak sits between 0.60 and 0.69 of depth in nine of the ten, with half inside a 0.63 to 0.69 core. The absolute layer index moves by a factor of five across that set and the fraction does not. 

The geometric collapse you highlight replicates on Llama and Gemma, each in its own domain. Steering replicates on Llama, Gemma, and Mistral. Patching on Llama and Mistral is running and is not in this revision.

We also stopped testing every model on money. Each model now decides in a different domain, listed in our common response.

**Q2. How does steering affect unrelated capabilities?**

Coherence of the generated text is the side effect we measure, since it bounds how far the vector can be pushed.

- We added a control the submission lacked. Every configuration is scored against a random direction of matched norm injected at the same layer.
- The steering vector beats that control in 77 of 80 sweep cells, across all four models.
- Above the swept range the output loses coherence. That is the documented failure mode of linear activation addition on a curved representation.

**Q3. What further evidence supports explicit control?**

The case rests on a gap we can now show on both sides.

The representation is clean. The causal peak sits at a consistent fractional depth across families, under prompts that state a horizon and prompts that do not. Horizon is an ordinal gradient that collapses into a binary choice at the turn boundary.

The behavior is not clean. In the reasoning zone, only the near option can deliver by the deadline. Our target takes the undeliverable option about half the time. It stays stable under relabelling, so that stability does not come from a coherent rule. The pattern holds across the open models we test.

A preference that is cleanly represented and unreliably acted on needs explicit control. The revised text opens the coherence section with that link.

**On the human baseline.**

The comparison used the Kirby non-drug-using control group rather than the clinical sample. We narrowed the paper to results that replicate across the campaign. The human reference comparison rested on one sample, so it no longer appears. The localization, geometry, and steering claims never depended on it.

**On Section 5.3 and Section 6.**

The steering section now reports a four-family sweep with the matched-norm control. The main text names the swept range and the best coefficient per model, with the full grid in Appendix B. Section 6 is rewritten and claims only what the results support.

The cross-scale evidence was already in the submission. Replication now spans four families and five domains. We ask whether this changes your assessment.
