
**Q1. Can the claims be confirmed on a different model family?**

Yes. Figure 3 now includes `gemma-2-9b-it` alongside the Qwen checkpoints, and the attention peak sits between 0.60 and 0.69 of depth in nine of ten checkpoints. The geometric collapse replicates on Llama and Gemma, each in its own domain. Steering replicates on Llama, Gemma, and Mistral.

The submission also already held two layers of cross-model evidence that the main text never showed. It patched nine Qwen checkpoints from 0.6B to 14B. It ran the behavioral battery across 10 families. Both are now in the main text.

**Q2. How does steering affect other functions of the model?**

Coherence of the generated text is the side effect we measure, since it bounds how far the vector can be pushed.

- We added a control the submission lacked. Every steering configuration is scored against a random direction of matched norm injected at the same layer.
- The steering vector beats that control in 77 of 80 sweep cells, across all four models.
- Above the swept range coherence degrades. A straight-line vector applied to a curved representation produces that degradation.

The direction of the shift shows in the generations themselves. Asked how to handle an unexpected crisis, the unsteered model opens with immediate triage. The long-term steered model opens with preparation, contingency planning, and building a standing team.

**Q3. Does this generalize beyond financial tradeoffs?**

Yes. Each model now decides in a different domain, and no model and domain pair repeats.

- Qwen3-4B-Instruct-2507: investment, in dollars.
- Llama-3.1-8B: health, in quality-adjusted life years.
- Gemma-2-9B: climate, in tonnes of carbon prevented.
- Mistral-7B: education, in lifetime earnings.
- Qwen3.5-4B: startup revenue.

Our minimally-framed prompts carry no times and no reward values at all. The model has to infer the horizon from framing. The open-ended generation comparison carries no financial content either.

**On the three weaknesses.**

- Steering degrades at high coefficients. The main text names the swept range and the best coefficient per model. The full grid is Appendix B, one table per model.
- Single-model validation is answered under Q1.
- Presentation is conceded in full. Definitions and the key evidence tables are in the main text. The appendix is two sections instead of thirty. The whitespace on pages 5 and 7 is gone.
