We thank the Area Chair for the meta review.

The meta review asked for evidence that the localization and steering directions replicate on at least one non-Qwen model or a different scale.
We now have both: three non-Qwen families, and scale within the Qwen family.

**Localization replicates across families.**

- We ran llama-3.1-8B-Instruct, gemma-2-9b-it, and mistral-7B-Instruct-v0.3 through the same pipeline as the submission.
- Causally identified attention components sit at similar fractional depth in all of them (gemma L25 of 42, llama L17 of 32, mistral L16 of 32, vs. L24 of 36 in the submission).
- The new sweeps cover every layer from the embedding up, and the early layers show no causal effect.
- Across scale, the submission already patched nine Qwen checkpoints from 0.6B to 14B (Appendix Q in original submission).

**Steering replicates and now has a control.**

- We inject a random direction of matched norm at the same layer and score it the same way.
- The steering vector beats the matched-norm perturbation in 77 of 80 sweep cells across the four models, and the steerable layer sits at similar fractional depth in each.
- Using IFEval, we measure that steering toward long-term preference costs about 3–5 percentage points of instruction-following accuracy.

**The domain is no longer narrow.**

- We leverage our parametric dataset to run financial, health, climate, education, and entrepreneurial framings.
- The same ordinal gradient geometry for time horizon appears in all of them.
- Linear probes read the preference at 95% or better in all four families, with shuffled-label controls at chance.

**The presentation is fixed.**

- The new draft has 8 pages of main text and 2 appendices, under 25 pages total, with the cross-model localization and probing tables in the main text.
- We removed the poem and the Kirby/drug-user study.
- We no longer claim a subgraph. We claim a set of located components at a measured fractional depth.

The full numbers are in our "New results" comment, and each reviewer reply maps them to that reviewer's questions.
With the replication in hand, the paper is a four-family, five-domain study of the same effect.
We hope this addresses the concern at the center of the meta review.
