We cannot upload the revised draft during the discussion phase, so this comment carries some presentation fixes.

## Dataset structure

| Paradigm | Size | Construction |
|---|---|---|
| Minimally-framed A/B | 1,000 pairs (500 explicit, 500 implicit) | overt temporal markers vs semantic framing only; counterbalanced over 2 orders and 7 label schemes |
| Highly-formatted parametric | 4,588 prompts | investment choices with explicit horizons from seconds to centuries |
| Classification | 160 pairs | short vs long goal classification over 25 life subdomains; 80/80 question orders |
| Behavioral | 960 prompts, 30 models | horizon, reward, order, label, and context varied on a grid |

## Figure 4, as a table

The review is right that the panels are unreadable in print.
The panels are per-sample PC1 trajectories of resid_post across layers 0 to 35, one panel per turn-transition token:

| Token | What the fan shows |
|---|---|
| im_end | fan-out from ~L21; long and short fully interleaved at every layer |
| \n | partial separation; a broad mixed band persists |
| im_start | mostly separated by ~L24; residual mixing near zero |
| assistant | two disjoint ribbons; clean separation |

The revision replaces these panels with vector figures.

## The revised paper structure

| Part | Pages |
|---|---|
| 1 Introduction | 1-2 |
| 2 Background and definitions | 2-3 |
| 3 Methodology | 3 |
| 4 Experimental setup | 3-4 |
| 5 Results: localization, geometry and behavior, steering | 4-8 |
| 6-8 Discussion, limitations, conclusion | 8 |
| References | 9-12 |
| Appendix A geometry, Appendix B steering | 13-19 |

