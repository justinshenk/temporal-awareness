Every number behind our replies is in this comment, taken from the revised draft's result tables.
One result stands out.
All four families carry the same temporal geometry, and only one behaves coherently over it.
A model can hold a representation and still fail to use it, so we recommend explicit control.

We write qwen, llama, gemma, mistral for Qwen3-4B-Instruct-2507, Llama-3.1-8B-Instruct, gemma-2-9b-it, Mistral-7B-Instruct-v0.3.

## Overview per model

Probe accuracy is held-out, with the shuffled-label control in parentheses.
Steering S is the forced-choice score against a random direction of matched norm, with the count of sweep cells where the vector wins.

| Model | Causal attn layer | Probe acc (shuffled) | Steering S vs ctrl (wins) | Temporal reasoning |
|---|---|---|---|---|
| qwen | L24 of 36 | 95.0% (52.8%) | 5.9 vs 2.9 (20/20) | 50.3% |
| llama | L17 of 32 | 95.8% (47.4%) | 17.4 vs 6.4 (18/20) | 52.4% |
| gemma | L25 of 42 | 95.8% (49.8%) | 3.9 vs 1.4 (20/20) | 95.1% |
| mistral | L16 of 32 | 96.7% (53.0%) | 12.1 vs 2.6 (19/20) | 51.0% |

Localization, probing, and steering replicate in every family.
Coherent behavior does not follow, and the next table takes up that gap.

## Geometry vs behavior

Temporal reasoning scores rational choice in the reasoning zone.
Order and label stability score whether a choice survives swapping or relabelling the options.
gpt-4o-mini is a frontier reference; qwen stability values are from the submission's reference run.

| Model | Ordinal geometry | Temporal reasoning | Order stability | Label stability |
|---|---|---|---|---|
| qwen | yes | 50.3% | 61.9% | 96.0% |
| llama | yes | 52.4% | 51.5% | 92.7% |
| gemma | yes | 95.1% | 94.8% | 95.2% |
| mistral | yes | 51.0% | 65.4% | 95.0% |
| gpt-4o-mini | not measured | 100.0% | 95.0% | 96.2% |

The geometry column is constant and the behavior columns are not.
Every model is stable to relabelling while reasoning varies, so the temporal capabilities move independently.
Steering below acts on the representation these models fail to use.

## Localization

All-layer patching sweeps on the three added families, next to the submission's sweep.
Scores are mean recovery plus disruption.

| Model | Top attn | Attn band | MLP peak |
|---|---|---|---|
| qwen | L24 (0.67) | 0.58–0.67 | L31, L35 |
| llama | L17 (0.55) | 0.45–0.58 | L26–L29 |
| gemma, climate | L25 (0.61) | 0.56–0.68 | L26, L32–L39 |
| gemma, investment | L28 (0.67) | 0.59–0.67 | L26, L38–L39 |
| mistral | L16 (0.52) | 0.48–0.61 | L28–L31 |

A causal attention band sits at middle depth in every family, and the layers below 0.2 of depth are causally silent in the models where we swept them.
The two gemma rows are independent runs on different domains that find the same band.
The best probe layer scatters across depth and does not track this band, so a probe alone does not locate where the preference is used.

## Steering

Best configuration per model, from a sweep over fractional depths 0.50 to 0.65 and four coefficients.

| Model | Layer (depth) | Coeff | S | S ctrl | Baseline | Wins |
|---|---|---|---|---|---|---|
| qwen | 18 (0.51) | 20 | 5.9 | 2.9 | 0.9 | 20/20 |
| llama | 18 (0.58) | 35 | 17.4 | 6.4 | 2.2 | 18/20 |
| gemma | 21 (0.51) | 50 | 3.9 | 1.4 | 1.4 | 20/20 |
| mistral | 19 (0.61) | 20 | 12.1 | 2.6 | −2.2 | 19/20 |

The effective layers sit around half of depth in all four models.

## Side effects on instruction following

IFEval accuracy, baseline to steered, in the long-term direction.
Moderate-strength steering costs three to five points.

| Model | Strict prompt | Strict instr | Loose prompt | Loose instr |
|---|---|---|---|---|
| qwen, coeff 50 | 0.705 to 0.659 | 0.786 to 0.752 | 0.722 to 0.681 | 0.799 to 0.766 |
| gemma, coeff 150 | 0.712 to 0.676 | 0.790 to 0.757 | 0.730 to 0.692 | 0.804 to 0.772 |

## Geometry: where preference collapses

Each new run draws 3,000 samples at the turn-transition tokens; the investment row is the submission's run.
Horizon is ordinal at the end of the user turn, and preference splits into two clusters by the assistant role token.
The panel is the layer where the split is cleanest.

| Model | Domain | Valid | Panel | Depth |
|---|---|---|---|---|
| qwen | investment | 4,588 | L31 of 36 | 0.86 |
| qwen | startup | 2,992 | L19 of 36 | 0.53 |
| llama | health | 2,517 | L21 of 32 | 0.66 |
| gemma | climate | 2,943 | L33 of 42 | 0.79 |
| mistral | education | 2,984 | L19 of 32 | 0.59 |

The same collapse appears in every family and survives a change of domain within one model.
Every family has the structure, and only gemma reasons coherently over it.
