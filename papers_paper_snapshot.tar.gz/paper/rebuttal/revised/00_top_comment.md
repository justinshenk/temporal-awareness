We thank the reviewers for the feedback.

We recognize our presentation was not effective, as it reported too much detail that obscured the narrative and results.
Additionally, we have widened our experimental scope by re-using the same pipeline presented in the paper on three new families.

From the time of the initial submission, we have had time to properly address the weaknesses pointed out by reviewers.

# New experiments

We have run new experiments that have widened the scope of our results:

We now consider four target models:
- qwen3-4B-Instruct-2507 (original)
- llama-3.1-8B-Instruct
- gemma-2-9b-it
- mistral-7B-Instruct-v0.3

We leverage our parametric dataset to incorporate more domains:
- financial (original)
- health
- climate
- education
- entrepreneurial

We strengthened the support in each stream:

**Steering: Added control.**

- We inject a random direction of matched norm at the same layer and score it the same way.
- The steering vector beats an arbitrary perturbation of the same magnitude in 77 of 80 sweep cells, across Qwen3-4B-Instruct-2507, Llama-3.1-8B-Instruct, gemma-2-9b-it, and Mistral-7B-Instruct-v0.3.
- The steerable layer sits at similar fractional depths in all four models.
- We also ran IFEval and showed steering the models toward long-term preference costs about 3–5 percentage points of instruction-following accuracy.

**Geometry: Pattern reproduces across families**

In all our new target models and new domains, we see the same geometric patterns:
- Time horizon shows ordinal gradient
- Geometry goes through transformations across change-of-turn positions

**Localization: Fractional depth across families**

Across model families and Qwen scale, we note:
- Causally identified attention components sit at similar fractional depth (gemma-2-9b-it L25 of 42, llama-3.1-8B L17 of 32, mistral-7B L16 of 32, vs. L24 of 36 in the submission)
- The new sweeps cover every layer from the embedding up, and the early layers show no causal effect
- All model geometry exists around causally identified layers
- Linear probes read the preference at 95% or better in all four families, with shuffled-label controls at chance


# Re-structured presentation

From the time of the original submission, we have received feedback from workshops and peers and we have been able to re-write our paper significantly.
We recognize our past presentation did not make clear some basic information. For instance, we had already included results of causal localization across scale in the Qwen family in the appendix, where it was easy to miss.

After rounds of revision, our new paper currently has:
- 8 pages of main text
- 2 appendices (geometry and steering)

The cross-model localization and probing tables now sit in the main text.

We radically cut down by:
- Removing Kirby/drug-user discounting study, but keeping the behavioral study that measures temporal preference stability and temporal reasoning coherence across families and scale
- Pruning unnecessary detail about already-standard methodologies, side-experiments that did not add to our stated contributions, and embellishing prose. 

For the camera-ready, we are considering this new title given the expanded scope: Temporal Concepts and their Shape in Large Language Models

We believe our new presentation makes our narrative and impact substantially more clear.

# Narrative

We would like to clarify the significance of our work:
- We use causal localization to show temporal concepts exist at similar fractional depth across families (qwen, llama, gemma, mistral) and domain (financial, health, climate, education, entrepreneurial)
- (novel) Around those fractional depths, we find that temporal horizon forms an ordinal gradient
- (novel) We show complex geometric transformations occur through change-of-turn tokens.
- We measure the temporal preference stability and temporal reasoning coherence and show that even though all models show striking geometry, the representational manifold is not always functional as it does not imply good intertemporal behavior (gemma-2-9b-it reaches 95% temporal reasoning coherence while similar-size models sit near 50%, despite similar geometry).
- We show steering could be used to shift temporal preference, inviting future work to further investigate how to leverage our identified temporal geometry to produce temporally-aligned behavior




