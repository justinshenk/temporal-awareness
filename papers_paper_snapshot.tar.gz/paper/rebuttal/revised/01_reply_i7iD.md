We thank the reviewer for the feedback.

To address the weaknesses, we:
- Replicate causal localization and geometry experiments across families, so the structure is not an idiosyncrasy of one model.
- Include more domains beyond the financial one.
- Remove the Kirby/drug-user study.

**Q1. Does the localization transfer to larger Qwen models or other families?**

Yes.

- Across scale: the submission already patched nine Qwen checkpoints from 0.6B to 14B (Appendix Q).
- Across families: we have now run llama-3.1-8B-Instruct, gemma-2-9b-it, and mistral-7B-Instruct-v0.3. Causally identified attention components sit at similar fractional depth in all of them (gemma L25 of 42, llama L17 of 32, mistral L16 of 32, vs. L24 of 36 in the submission).

**Q2. How does steering affect unrelated capabilities?**

Steering degrades capabilities as a function of magnitude.
Using IFEval, we measure that steering Qwen3-4B-Instruct-2507 and gemma-2-9b-it toward long-term preference costs about 3 to 5 percentage points of instruction-following accuracy.

**Q3. Why do we recommend explicit control?**

Across families (qwen, llama, gemma, mistral) and domains (financial, health, climate, education, entrepreneurial), we find ordinal gradient geometry for time horizon.

However, some models that show representational geometry still fail to behave with stable temporal preference and coherent temporal reasoning.
For instance, both gemma-2-9b-it and qwen3-4B-Instruct-2507 show time horizon geometry that clearly differentiates time scale.
While gemma reaches 95% temporal reasoning coherence, qwen fails at 50%.

If representational geometry exists, we suggest that it should be leveraged to ensure good intertemporal behavior in models that fail to operate on it correctly.



