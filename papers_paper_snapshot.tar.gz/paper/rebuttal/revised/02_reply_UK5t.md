We thank the reviewer for the feedback.

To address the weaknesses, we:
- Radically re-structured our presentation. We incorporated feedback from workshops that allowed us to distill the paper and appendices to under 25 pages total.
- Expanded the experimental scope using the very same pipeline from the paper, applied to new models.
- Used IFEval to characterize the degradation induced by linear steering.

**Q1. Can the claims be confirmed on a different model family?**

Yes.

We now consider four target models:
- qwen3-4B-Instruct-2507 (original)
- llama-3.1-8B-Instruct
- gemma-2-9b-it
- mistral-7B-Instruct-v0.3

**Q2. How does steering affect other functions of the model?**

Steering degrades capabilities as a function of magnitude.

Using IFEval, we measure that steering Qwen3-4B-Instruct-2507 and gemma-2-9b-it toward long-term preference costs about 3 to 5 percentage points of instruction-following accuracy.

**Q3. Does this generalize beyond financial tradeoffs?**

Yes.

We leverage our parametric dataset to incorporate more domains:
- financial (original)
- health
- climate
- education
- entrepreneurial

Two new domains extend financial trade-offs beyond simple investment:
- lifetime earnings (education)
- start-up revenue (entrepreneurial)

We also include non-financial domains, with units of:
- quality-adjusted life years (health)
- tonnes of carbon prevented (climate)

The model must infer the time horizon from the framing in each domain. The same geometric structure appears in all of them, and the located components sit at similar fractional depth.
