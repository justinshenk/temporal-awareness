We thank the reviewer for the detailed review.

The presentation criticisms are correct, and we concede them in full.
Since the original submission in May, we have received feedback from peers and workshop reviewers.
We have radically re-designed our presentation.

**W1. The main text is not self-contained, and the appendix runs over 100 pages.**

We restructured. The new draft has 8 pages of main text and 2 appendices, under 25 pages total.
Definitions, method summaries, dataset structure, and the cross-model localization and probing tables now sit in the main text.
The appendices provide geometric visualizations and steering experiment controls.

**W2. The figures are low-resolution bitmaps.**

The localization figures are vector with labeled axes.
The PCA panels are now vector as well.
We fixed the cross-model geometry panels.

Since the paper is now under 25 pages, we include higher-resolution images without increasing the PDF file size.

**W3. Only one model is studied.**

Our initial submission was too methodologically oriented and neglected experimental scope.
Since May, we have widened the scope of our experiments.

We now consider four target models:
- qwen3-4B-Instruct-2507 (original)
- llama-3.1-8B-Instruct
- gemma-2-9b-it
- mistral-7B-Instruct-v0.3

We leverage our parametric dataset to incorporate more domains:
- financial (original)
- health
- climate
- education
- entrepreneurial

**W4. A subgraph claim requires edges.**

We agree and take the conservative route. We no longer claim a subgraph.
Our localization experiments show that most models have their top causal components around the same fractional depth.
The purpose of our localization is to show that the same depth has a causal effect across our three datasets (minimally framed, highly formatted, classification) that cover different temporal tasks.
We then look at the representational geometry around those identified components.

**W5. The coherence section seems disconnected.**

Across families (qwen, llama, gemma, mistral) and domains (financial, health, climate, education, entrepreneurial), we find ordinal gradient geometry for time horizon.

However, some models that show representational geometry still fail to behave with stable temporal preference and coherent temporal reasoning.
For instance, both gemma-2-9b-it and qwen3-4B-Instruct-2507 show time horizon geometry that clearly differentiates time scale.
While gemma reaches 95% temporal reasoning coherence, qwen fails at 50%.

If representational geometry exists, we suggest that it should be leveraged to ensure good intertemporal behavior in models that fail to operate on it correctly.

Thus, measuring coherence in temporal reasoning helps us connect the behavioral account to the geometric account by showing that:
- The existence of clear geometric temporal structure (time horizon) does not imply good intertemporal behavior.
- Different temporal capabilities work independently. Stable temporal preference (independent of label and order) does not necessarily enable the model to leverage its internal temporal concepts for capabilities (coherent temporal reasoning).

**W6. The introductory poem.**

We apologize for the tone issues. The poem was an attempt to convey that temporal decisions carry deep meaning for humans. We see now that it was ineffective. It is gone, and the space now carries the definitions the paper needs to be self-contained.
