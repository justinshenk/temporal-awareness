# NeurIPS 2026 rebuttal, submission 25332

## Build

```
bash build_rebuttal.sh
```

This regenerates `rebuttal.pdf` from the Markdown files and prints a character count
for each comment. The Markdown is the source of truth. Edit a `.md`, re-run the script,
and the PDF follows.

## Files to post on OpenReview

In each file, the `**Title:**` line goes in OpenReview's title field, and everything
below the `---` rule goes in the comment box. OpenReview renders Markdown and caps a
comment at 5000 characters. All five fit.

| # | File | Post as | Characters |
|---|---|---|---|
| 1 | `00_official_comment.md` | Official Comment, readers: everyone | 3,333 |
| 2 | `01_replication_update.md` | Official Comment, readers: everyone | 3,217 |
| 3 | `reviewer_i7iD.md` | Rebuttal under i7iD's review | 2,999 |
| 4 | `reviewer_UK5t.md` | Rebuttal under UK5t's review | 2,417 |
| 5 | `reviewer_APpt.md` | Rebuttal under APpt's review | 2,755 |
| 6 | `ac_confidential.md` | Author AC Confidential Comment | 3,044 |

Post in that order, since each per-reviewer reply points back to the common comments' tables.
`01_replication_update.md` carries the verified cross-model tables: geometry, all-layer localization, probing, steering with the matched-norm control, and coherence.

## Working documents, not for posting

- `paper_revision_plan.md` covers what changes in the paper: the restructure, the claim
  calibration, and every technical correction from the PAT report.
- `resources/` holds the sources. `neurips.pdf` and `temp_review.pdf` are the same
  OpenReview thread at two timestamps. `colm.pdf` is the rejected COLM workshop
  submission, whose reviewers raise the same scope and presentation problems.
  `co_collab_ideas.pdf` and `some_new_exp.pptx.pdf` hold the gemma-2-9b-it results.

## Where the reviewers stand

| Reviewer | Rating | Confidence | Core objection |
|---|---|---|---|
| i7iD | 3, borderline reject | 4 | Single model, steering section underdeveloped |
| UK5t | 3, borderline reject | 2 | Single model, financial domain only, presentation |
| APpt | 2, reject | 4 | Main text not self-contained, bitmap figures, subgraph claim |

The AC's explicit bar is replication on a non-Qwen model or a different scale. Both
halves are now covered: the scale half was already in the submission (Appendix Q, nine
Qwen3 variants), and the non-Qwen half is the new gemma-2-9b-it run.

## State of the paper these comments describe

Main text is 9 pages. The appendix is three sections: geometry across models,
causal localization and probing across models, and contrastive steering. The comments
refer to results by name, not by appendix letter, so they stay correct as the
revision settles.

## Before posting

Read section F of `paper_revision_plan.md`. The open question that matters most is the
gemma steering layer, where our two source documents disagree.
