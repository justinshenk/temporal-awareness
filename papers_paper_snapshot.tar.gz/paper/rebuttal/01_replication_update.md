# Official Comment (all reviewers), replication update

<!-- POST AS: Official Comment. Readers: everyone. Post after 00_official_comment. -->
<!-- Paste everything below the line. OpenReview renders Markdown. Limit 5000 characters. -->

**Title:** Update: verified replication tables, four families and five studies

---

The remaining campaign runs have finished and been verified. This comment carries the numbers. Five studies now cover four families, one domain per model. A fifth run reuses the target model on a startup domain. The planned Qwen3.5-4B run is architecturally incompatible with our patching stack, so we report that run as a domain check on the target model.

**Geometry.** The turn-boundary collapse replicates in every run, at each family's own turn tokens. Depth is fractional.

| Model / domain | Collapse panel | Depth |
|---|---|---|
| Qwen3-4B / startup | L19 of 36 | 0.53 |
| Mistral-7B / education | L19 of 32 | 0.59 |
| Llama-3.1-8B / health | L21 of 32 | 0.66 |
| gemma-2-9b / climate | L33 of 42 | 0.79 |

**Causal localization, all layers.** The submission's sweep on the target model had a floor at 0.45 of depth, so the silence of the early layers was an assumption. The new sweeps cover every layer (24 contrastive pairs, resid/attn/MLP, denoising and noising) and measure it.

| Model | Top attention (depth) | Attention band | MLP | Early layers (<0.2) |
|---|---|---|---|---|
| Llama-3.1-8B | L17 (0.55) | 0.45-0.58 | late, L26-L29 | -0.010 |
| gemma-2-9b | L25 (0.61) | 0.56-0.68 | L26 + L32-L39 | -0.026 |
| Mistral-7B | L16 (0.52) | 0.48-0.61 | late, L28-L31 | -0.006 |
| Qwen3-4B (submission) | L24 (0.67) | 0.58-0.67 | L31, L35 | not swept |

**Probing.** Per-layer logistic probes, pair-aware 80/20 split, shuffled-label control, zero-shot transfer to the explicit set.

| Model | Best layer (depth) | Accuracy | Shuffled | Transfer |
|---|---|---|---|---|
| Qwen3-4B | L17 (0.47) | 95.0% | 52.8% | 74.2% |
| Llama-3.1-8B | L29 (0.91) | 95.8% | 47.4% | 70.1% |
| gemma-2-9b | L23 (0.55) | 95.8% | 49.8% | 85.8% |
| Mistral-7B | L14 (0.44) | 96.7% | 53.0% | 85.8% |

**Steering against a matched-norm random control.** Best cell per model; the vector beats the control in 77 of 80 sweep cells.

| Model | Layer, alpha | S steer | S control | Baseline | Beats ctrl |
|---|---|---|---|---|---|
| Llama-3.1-8B | L18, 35 | 17.4 | 6.4 | 2.2 | 18/20 |
| Mistral-7B | L19, 20 | 12.1 | 2.6 | -2.2 | 19/20 |
| Qwen3-4B | L18, 20 | 5.9 | 2.9 | 0.9 | 20/20 |
| gemma-2-9b | L21, 50 | 3.9 | 1.4 | 1.4 | 20/20 |

**Coherence, same 960-prompt grid.** Zone coherence is the share of reasoning-zone choices that pick the only option able to deliver in time.

| Model | Zone coherence |
|---|---|
| gpt-4o-mini | 100.0% |
| gemma-2-9b | 95.1% |
| Llama-3.1-8B | 52.4% |
| Mistral-7B | 51.0% |
| Qwen3-4B | 50.3% |

Our Qwen re-run scores 50.3% against 50.0% recomputed from the submission's reference run, so the instrument reproduces. gemma-2-9b reaches the coherent range while the other three local models sit at chance. That refines the submission's claim that only frontier API models get there.

**Three regularities hold in every family.**

1. A mid-depth causal attention band that contains or abuts that model's best steering layer.
2. Late-layer MLP accumulation.
3. Early layers measured causally silent wherever the sweep reached them.

All artifacts, including the four turn-collapse figure sets under `geometry/fig7_final`, are on the Hugging Face dataset `unrulyabstractions/temporal-awareness`.

**Side effects on instruction following.** We steer each model in the long-term direction and score it on IFEval before and after. Moderate-strength steering costs three to five points, and the cost is similar in both families.

| Model (alpha, N) | Strict prompt | Strict instr. | Loose prompt | Loose instr. |
|---|---|---|---|---|
| Qwen3-4B (50, 464) | 0.705 to 0.659 | 0.786 to 0.752 | 0.722 to 0.681 | 0.799 to 0.766 |
| gemma-2-9b (150, 510) | 0.712 to 0.676 | 0.790 to 0.757 | 0.730 to 0.692 | 0.804 to 0.772 |

**A second, independent gemma-2-9b localization, investment domain.** Causal parametric patching on 88 constraint-only pairs from 4,590 prompts. The resid_post window is L22-L32 under denoising (0.52-0.76 of depth) and L24-L39 under noising. Top attention layers are L28, L26, L25 (0.59-0.67); top MLP layers are L38, L39. The investment and climate runs find the same attention band at 0.56-0.68 of depth; the investment run swept from L22 up, while the climate run swept every layer and measured the early layers causally silent.

**Probe agreement.** Two independent probe implementations both select L23 (0.55 of depth) as gemma's best probe layer.

**Vector recipe.** A variant that takes the mean of teacher-forced label activations at the best probe layer also steers gemma at larger magnitude (alpha=150 at L25), so the steering effect is robust to the vector recipe.
