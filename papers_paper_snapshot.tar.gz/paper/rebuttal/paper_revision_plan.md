# Paper revision plan

Working document. Not for posting. Every item below is something we committed to in a
rebuttal file, or a concrete defect a reviewer or the PAT report identified.

## A. Structural changes the reviewers demand

All three reviewers and both COLM reviewers raised presentation. This is the single
largest block of work.

1. **Make the main text self-contained.** Move the task definition (currently Section 2.1
   area, flagged at line 115), the method (line 142), and the dataset structure (line 157)
   out of the appendix and into the main text. APpt calls the current arrangement
   unacceptable; UK5t and both COLM reviewers say the same thing in softer words.
2. **Cut the appendix.** It is over 100 pages across roughly 30 sections. Decide what is
   evidence and what is a lab notebook, and delete the notebook.
3. **Regenerate main-text figures as vector art.** Figure 4 is the named example: axis
   labels and legends are unreadable. These figures carry the localization evidence.
4. **Fix float placement.** UK5t names excessive white space on pages 5 and 7.
5. **Remove the epigraph** and restructure the introduction around techniques and prior work.
6. **Fix the appendix visual tour on pages 19-20.** Figures are duplicated (the PCA fan
   labeled "Appendix L, p. 68" appears four times across two pages, the Appendix O bar
   charts repeat) and captions are misaligned with images.
7. **Verify the template.** APpt suspects the font and in-text citation format deviate from
   the stock NeurIPS template. This is likely real: `paperdefs.tex` loads `lmodern` for the
   NeurIPS build, which changes the text font, and `main.tex` passes `numbers` to `natbib`.
   Build against the unmodified `neurips_2026.sty` and revert deviations.

## B. Claim calibration

1. **The subgraph claim is defensible, but the evidence is not shown.** Appendix V does
   describe a two-stage procedure: EAP-IG restricts the candidate node set, then edges
   between those nodes are scored and pruned to a sparse functional subgraph. So the
   earlier plan to concede the term outright was wrong. What is missing is the *results*:
   `appendix/localize/attributional_contrastive.tex` contains no edge-level numbers, and no
   edge count or sparsity figure appears anywhere in the paper. Surface the edge results
   (sparsity, top edges, recovery metric) in the main text. Keep *component set* as the
   fallback term only if those results do not materialize.
2. **Scope the discussion.** i7iD says Section 6 draws alignment conclusions beyond the
   experiments. Cut to what the evidence supports.
3. **Address the specificity objection.** COLM reviewer Bo3D notes the localized region also
   decodes an unrelated meta-cognitive variable at high accuracy, which suggests a general
   decision or turn-transition region rather than a temporal-preference-specific mechanism.
   The paper acknowledges this but does not adjust its claims. Either adjust the claims or
   add the ablation that separates the two.
4. **Fix the contradicted limitations.** Section 7 (line 204) and Appendix F (lines 906-908)
   say replication across scales would test generalization, but Appendix Q already does the
   cross-scale patching over nine Qwen3 variants, and Appendix AD now adds a non-Qwen family.
   Rewrite so the demonstrated scope is two families plus one scale sweep, and the open
   question is broader family coverage.
5. **Name the human discounting comparison group.** i7iD assumes the baseline is the
   clinical population. It is not. Kirby MCQ-27 reports both a non-drug-using control group
   (k about 0.013) and a heroin-dependent group (k about 0.025), and the paper's headline
   "3 to 8 times more patient" figure is computed against the control group: 0.013/0.0041 is
   3.2 and 0.013/0.0016 is 8.1. No replacement is needed. The text simply never says which
   group it compares against, so say it.

## C. New results to fold in

From the gemma-2-9b-it work (see `resources/some_new_exp.pptx.pdf`):

1. Cross-family localization table and the Gemma2-9B component ranking figure.
2. Cross-family steering table, including the probing-steering dissociation holding in a
   second family.
3. IFEval evaluation of both steered models. This also answers i7iD Q2 and UK5t Q2.
4. Promote the non-financial evidence (open-ended generation, minutes-to-prepare horizon
   estimation) into the main text to answer UK5t Q3.
5. Move the alpha and layer sweeps into the main text so the usable steering range is visible.

## D. Technical corrections from the PAT report

These are author-only feedback and reviewers never saw them. They are still real defects and
several are the kind a camera-ready reviewer would catch.

**Contradictions to resolve:**

- **Steering vector definition.** Appendix T.2 (lines 2389-2391) says the probe's coefficient
  vector is used as the CAA direction. Appendix AA.1 (Equation AA.1) defines it as a
  difference in means. These are different objects. State which was used.
- **EAP-IG interpolation space.** Appendix U.1 (line 2412) says interpolation happens in
  embedding space, Equation U.1 integrates over intermediate activation space. Reconcile.
- **"Redundant" vs "AND-like".** Figure I.3a caption (line 1126) calls a regime redundant;
  Figure I.4a labels the same regime AND-like / necessary. These are opposites.
- **Table K.1 convergence.** Lists "Attn L18, L26, L30, L33", but Appendix J.2 gives the
  dominant attention writers as L21, L24, L26, L30 and says the first fifteen layers show no
  significant attention effect. L18 looks like a misattribution from the `resid_pre` metrics.
- **Marginal contribution.** Appendix I.2 (line 1098) defines it as `resid_post[L] - resid_pre[L]`,
  but Figure I.2 plots downstream causal effect metrics.

**Arithmetic and statistics:**

- **Table G.1.** Reports 99.2% best test accuracy and "+52.3 pp above chance". Chance is 50%,
  so the signal is +49.2 pp.
- **The +1.22 log-probability claim.** Table R.2's caption reads it as 3.4x more probability
  mass on long-term completions. Since the score is a difference in log-probabilities,
  exp(1.22) = 3.39 is a multiplier on the *odds ratio*, not on probability mass.
- **Survivorship bias in discounting.** Appendix N.2: for "4B Heroin CoT" a boundary was found
  in 3 of 27 trials. If mean and median k come only from those 3, the reported impulsivity is
  biased downward. State how the 24 unbounded trials are handled.
- **Open-ended steering dispersion.** Table R.3 reports means over 13 prompts per condition
  with no standard deviation, standard error, or confidence interval. Add dispersion.
- **Cross-model patching denominator.** Appendix Q uses the 160-pair bank selected because the
  4B model classified it correctly. For small variants the clean-corrupted logit difference
  approaches zero and the normalized score blows up. State whether per-model filtering was applied.
- **Appendix J.1.1.** "Layers 20-27" is called a seven-layer staircase; the inclusive range is 8.

**Unstated dataset filtering (reproducibility):**

- Appendix I uses n = 71 pairs from a pool of 4,588; Appendix M splits that into 57 constrained
  and 10 unconstrained, leaving 4 unaccounted for.
- Appendix W.3 defines "45 strong pairs" and "24 strongest pairs", while Appendix J says
  patching used 160 pairs. Say whether the smaller subsets are used anywhere or are vestigial.
- "45 strong pairs" is described as having balanced question order, which an odd number cannot have.
- Appendix Q relies on 1,100 temporal preference samples with no stated selection rule.
- Appendix X.2 does not say how `null` time horizons are handled in `log10(time_horizon)`.
- Appendix U.2 does not document `m`, the number of integration steps for the Riemann sum.

**Notation and minor:**

- Equation A.1 switches to `V(t) = lambda(t) * r(t)` while the main text uses subscripts. Align to Equation 1.
- Equation U.1 is missing the differential `d(alpha)`.
- Equation U.2 summation bounds give one term too many for the stated normalization.
- Section U.2.1: write the normalization explicitly as `s_bar_A = s_A / delta L_A`.
- Equation V.3: say the interpolated position is rounded, not just clamped.
- Equation AB.5: define `H_string`.
- Table B.1: rename the "Geometry" column to "Non-linear geometry".
- Reference [2] (line 220): capitalize proper nouns ("Dario Amodei", "Department of War").

**Checklist:**

- Q12 (licenses for existing assets) is `[N/A]` but we use Qwen3, Claude, GPT, and Kirby MCQ-27.
- Q13 (new assets) is `[N/A]` but we introduce the explicit and implicit prompt sets.

## E. Citations to add

The PAT report names prior work we should engage rather than ignore.

- Panickssery et al., Steering Llama 2 via contrastive activation addition, 2024. Acknowledge
  as the foundation of the CAA method we use.
- Zou et al., Representation Engineering, 2023. Context for the read/write depth dissociation.
- Turpin et al., Language models don't always say what they think, 2023, and Cox et al.,
  Post-hoc reasoning in chain-of-thought, 2025. Ground the CoT-as-confabulation claim.
- Chen et al., LLM economicus?, 2024. Our finding that CoT amplifies present bias contradicts
  this, and we should say so directly rather than leave the divergence unremarked.
- Cook et al., What do LLMs want?, 2026, and Zhu et al., Language models trained to do
  arithmetic predict human risky and intertemporal choice, 2025. Behavioral economics context.
- A citation for linear steering degrading output quality beyond a usable range, to support the
  answer to UK5t. Not yet identified.

## F. Open questions for the team

1. **The gemma steering layer is inconsistent between our own two source documents.** The
   results table in both `co_collab_ideas.pdf` and `some_new_exp.pptx.pdf` gives the best
   steering layer for `gemma-2-9b-it` as **L25 (0.59 depth)**. The conclusion paragraph in
   `co_collab_ideas.pdf` instead says the concept is written "at L23 before the L28 for
   gemma2". L23 is the best *probe* layer, not the steering layer. The rebuttal files use
   **L25**, since two tables agree on it. Confirm before posting.
2. The collaborator draft claims the IFEval drop is "~0.03 instruction-level and ~0.05
   prompt-level". Instruction level checks out (3.2 to 3.4 pp across all four measurements).
   Prompt level does not: the actual range is 3.6 to 4.6 pp, so 0.05 overstates it. The
   rebuttal files say "about three points" and "about four points". Do not reuse the 0.05
   figure in the paper.
3. i7iD Q3 was marked "We cannot… I think?" in the collaborator draft. The rebuttal answers by
   narrowing the claim rather than defending it. Confirm that is the line we want.
4. Who posts, and in what order? Suggested: common Official Comment first, then the three
   per-reviewer replies pointing back to it.
5. Do we upload a revised PDF during the discussion period, or only promise the revision?
