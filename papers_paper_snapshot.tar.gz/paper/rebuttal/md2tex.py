#!/usr/bin/env python3
"""Build a standalone rebuttal.tex from the Markdown comments.

The output compiles with plain pdflatex and needs no unusual packages, so it
drops straight into Overleaf. Run this after editing any .md file.
"""
import io, re, sys

FILES = [
    ("00_official_comment.md", "Official Comment, readers: everyone"),
    ("reviewer_i7iD.md",       "Rebuttal under Reviewer i7iD"),
    ("reviewer_UK5t.md",       "Rebuttal under Reviewer UK5t"),
    ("reviewer_APpt.md",       "Rebuttal under Reviewer APpt"),
    ("ac_confidential.md",     "Author AC Confidential Comment"),
]

def esc(t):
    """Escape LaTeX specials, then restore inline markup."""
    t = t.replace("\\", "\\textbackslash{}")
    for c in "&%$#_{}":
        t = t.replace(c, "\\" + c)
    t = t.replace("~", "\\textasciitilde{}").replace("^", "\\textasciicircum{}")
    t = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", t)
    t = re.sub(r"`(.+?)`", r"\\texttt{\1}", t)
    return t

def title_of(src):
    m = re.search(r"^\*\*Title:\*\*\s*(.+)$", src, re.M)
    return m.group(1).strip() if m else ""

def body_of(src):
    return src.split("\n---\n", 1)[1] if "\n---\n" in src else src

def convert(body):
    out, in_list = [], False
    for raw in body.split("\n"):
        line = raw.rstrip()
        if line.startswith("- "):
            if not in_list:
                out.append(r"\begin{itemize}\itemsep2pt")
                in_list = True
            out.append(r"  \item " + esc(line[2:]))
            continue
        if in_list and not line.strip():
            out.append(r"\end{itemize}")
            in_list = False
            continue
        if in_list:
            out[-1] += " " + esc(line.strip())
            continue
        if line.startswith("## "):
            out.append("")
            out.append(r"\rebheading{" + esc(line[3:]) + "}")
        elif not line.strip():
            out.append("")
        else:
            out.append(esc(line))
    if in_list:
        out.append(r"\end{itemize}")
    return "\n".join(out)

PRE = r"""% Rebuttal for NeurIPS 2026 Submission 25332.
% Self-contained: compiles with pdflatex, no unusual packages.
% Each section below is one OpenReview comment. Paste the body, not the heading.
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{enumitem}
\usepackage{xcolor}
\usepackage[colorlinks=true,linkcolor=black,urlcolor=blue]{hyperref}
\usepackage{titlesec}
\usepackage{fancyhdr}

\setlength{\parindent}{0pt}
\setlength{\parskip}{0.55em}
\setlist[itemize]{leftmargin=1.3em,topsep=0.3em,itemsep=0.2em,parsep=0pt}

\titleformat{\section}{\large\bfseries}{}{0pt}{}
\titlespacing{\section}{0pt}{1.6em}{0.6em}
\newcommand{\rebheading}[1]{\medskip{\bfseries\itshape #1}\par\nobreak\smallskip}
\newcommand{\postas}[1]{{\small\color{gray!70!black}Post as: #1}\par\smallskip}

\pagestyle{fancy}\fancyhf{}
\rhead{\small NeurIPS 2026 Submission 25332}
\lhead{\small Rebuttal}
\cfoot{\thepage}
\renewcommand{\headrulewidth}{0.4pt}

\begin{document}
"""

def main():
    parts = [PRE]
    for fname, postas in FILES:
        src = io.open(fname, encoding="utf8").read()
        parts.append("\\section*{" + esc(title_of(src)) + "}")
        parts.append("\\postas{" + esc(postas) + "}")
        parts.append(convert(body_of(src)).strip())
        parts.append(r"\clearpage")
    parts[-1] = r"\end{document}"
    io.open("rebuttal.tex", "w", encoding="utf8").write("\n".join(parts) + "\n")
    print("wrote rebuttal.tex")

main()
