
## 2026-08-01 — paper rebuild for the rebuttal

- **`out/preprint.pdf` (16 pages)**. Verified: ran `bash build.sh`, captured the real
  exit code (0, not swallowed by a pipe), then checked the log with newlines stripped:
  0 undefined references, 0 undefined citations, 0 multiply-defined labels.
  `pdftotext` on the built PDF returns 0 occurrences of `??`, 0 doubled words, and 0
  occurrences of EAP-IG / attribution patching / subgraph. **VERIFIED**.
- **`images/localize/depth_across_models.pdf`**. Redesigned to one row per model with
  the prompt condition encoded as a filled dot inside a ring. Verified by rendering to
  PNG at 190 dpi and reading it with image tokens: family grouping correct, no label
  collisions, no wasted margin. **VERIFIED**.
- **`images/localize/probe_across_models.pdf`** (new). Built from the probing CSVs
  pulled from the HF dataset. Verified by rendering to PNG and reading it: four model
  lines legible, direct labels de-collided, shuffled-label control panel present.
  Palette checked with the dataviz validator: all six checks PASS. **VERIFIED**.
- **Probing data provenance**. Pulled `probing/turn_preference/*.csv` and `*_meta.json`
  from `unrulyabstractions/temporal-awareness` on HF and opened them. Shuffled-label
  control sits at chance in all four models. The best probe layer scatters across
  fractional depth and does not coincide with the causal band, so the earlier claim that
  probing peaks inside the band was **BROKEN** and has been corrected in the text.
- **Steering sweep CSVs** pulled for four models. Contain `S_ctrl` and `beats_ctrl`
  columns. **NOT YET INTEGRATED** into the paper; the steering appendix still reports the
  original single-model sweep. Listed here as **UNVERIFIED** in the paper's current text.
- **Pages 1-16 visual check**. Dispatched three independent verifier agents to read every
  rendered page with image tokens. Results pending at the time of writing.

## 2026-08-01 — cross-model results folded into paper and rebuttal (v5 source)

- **`appendix/localize/localization_across_models.tex` (Appendix B, pages 15-16)**.
  Compiled to a scratch dir (never build.sh) and read the rendered pages with image
  tokens: both tables match new_results.md v5 section 2 and 3 rows exactly
  (L24/L17/L25/L16 attention peaks; probe rows L17/L29/L23/L14 with 95.0-96.7%).
  **VERIFIED**.
- **`appendix/characterize/geometry_across_models.tex` (Appendix A, pages 12-14)**.
  Read rendered pages: Table A.1 rows match v5 section 1 (L31 0.86, L19 0.53,
  L19 0.59, L21 0.66, L33 0.79; valid counts 2,992 / 2,984 / 2,517 / 2,943);
  Llama and Gemma panels render. **VERIFIED**.
- **`sections/results.tex` edits (pages 4-6)**. Read rendered pages: 0.45-floor
  strengthening present in 5.1, probe-scatter sentence cites Appendix B, coherence
  anchor sentence present, Figure 5 caption carries 50.3% vs 50.0% and 95.1%.
  **VERIFIED**.
- **Full compile**: pdflatex x2 + bibtex + pdflatex x2 into the scratchpad, rc=0,
  18 pages, 0 undefined citations/references after fresh bibtex (the stale root
  main.bbl lacks hanna2024faithfaithfulnessgoesfaithful; resolves on next full
  build). No repo-root pollution. **VERIFIED**.
- **`rebuttal/01_replication_update.md` + rebuilt `rebuttal.pdf`**. build_rebuttal.sh
  reports 3,217/5000 chars; read rendered PDF pages 2-3 with image tokens: all five
  tables present and matching v5. **VERIFIED**.
- **Not verified**: out/preprint.pdf was NOT rebuilt (build.sh deploys publicly and
  was not run); the deployed PDF does not yet contain these edits. The concurrent
  session's rebuttal/revised/*.md were read and left untouched.

## 2026-08-01 — IFEval side effects, investment-domain gemma localization, probe agreement, vector recipe

- **`appendix/intervene/contrastive_steering.tex`: IFEval subsection (Table C.5, page 18)**.
  Compiled with pdflatex+bibtex into the session scratchpad (never build.sh), rendered
  page 18 to PNG, and read it with image tokens: Table C.5 shows Qwen strict prompt
  0.705/0.659, strict instruction 0.786/0.752, loose 0.722/0.681 and 0.799/0.766; gemma
  0.712/0.676, 0.790/0.757, 0.730/0.692, 0.804/0.772; citation resolves to [58].
  **VERIFIED**.
- **`appendix/intervene/contrastive_steering.tex`: vector-recipe paragraph (page 17)**.
  Read rendered page 17: paragraph present under Controls, alpha=150 at L25 stated.
  **VERIFIED**.
- **`appendix/localize/localization_across_models.tex`: investment row + paragraph +
  probe-agreement sentence (page 15)**. Read rendered page 15: Table B.1 carries the
  new `gemma-2-9b-it, investment` row (L28 0.67, band 0.59-0.67, MLP L26/L38-L39, not
  swept); the paragraph states 88 pairs from 4,590 prompts, denoising L22-L32, noising
  L24-L39; B.1 probing text carries the L23 (0.54-0.55) agreement sentence. **VERIFIED**.
- **Compile health**: final pdflatex pass rc=0 after bibtex; grep of the scratch
  `main.log` finds no undefined references and no multiply-defined labels; bibtex ran
  clean with one pre-existing unrelated warning (extra url field). **VERIFIED**.
- **`rebuttal/01_replication_update.md` append**: re-ran `wc -c` after the append,
  4,936 characters, under the 5,000 OpenReview limit. **VERIFIED**.
- Not rebuilt via `build.sh`, so `out/preprint.pdf` does not yet include these edits.
  Listed as **UNVERIFIED** for the deployed PDF.

## 2026-08-01 — Full build + deploy (user-directed)
- Ran `bash build.sh` per user instruction: review/preprint/camera_ready all built, rc=0; preprint deployed to unrulyabstractions.github.io/pdfs/temporalpref.pdf.
- Verified the DEPLOYED preprint content directly (pdftotext on out/preprint.pdf, 19pp, built 15:04): IFEval table present (2 mentions), Mistral results present (11), "causally silent" early-layer claim (3), coherence anchor 50.3 (1). All four cross-model geometry figures compile (build succeeded after commit 5e09785 added them).
- The deployed PDF now matches the repo state including all campaign + collaborator results. VERIFIED.

## 2026-08-01 — Figure 3 depth_across_models: three replication rows added
- **Peak layers for the new rows**: computed from the HF archives `localization/loc_llama_health.tar.gz`, `loc_gemma_climate.tar.gz`, `loc_mistral_education.tar.gz` via `CoarseActPatchAggregatedResults` on `aggregated/coarse/{attn_out,mlp_out}.json`, horizon pairs only, ranked by mean recovery + disruption. Llama-3.1-8B attn L17 / mlp L29 (denom 31); Mistral-7B attn L16 / mlp L31 (denom 31); gemma climate attn L25 / mlp L26 (denom 41). All match the Appendix B sanity values (Table tab:localization-across-models). **VERIFIED**.
- **`images/localize/depth_across_models.pdf`**: regenerated by `figures/make_depth_figure.py`, rendered to PNG at 300dpi and viewed with image tokens; 15 rows, new rows at expected x positions (gemma-climate attn 0.61 / mlp 0.63, Llama attn 0.55 / mlp 0.94, Mistral attn 0.52 / mlp 1.0), probe triangles at 0.56 / 0.94 / 0.45, family gaps correct, existing gemma row relabeled "(investment)". **VERIFIED**.
- **Caption (`sections/results.tex`)**: updated IQR 0.61-0.69 (script output) and added Gemma two-row explanation; confirmed in the deployed preprint via pdftotext. **VERIFIED**.
- **Build + deploy**: `bash build.sh` built review/preprint/camera_ready (each ~1.9MB, fresh timestamps), deployed preprint to unrulyabstractions.github.io/pdfs/temporalpref.pdf; preprint.log has 0 undefined/multiply-defined; rendered preprint page 5 at 150dpi and viewed with image tokens: figure and caption present and correct. **VERIFIED**.
- Probe markers for the three new rows come from the same per-layer probe sweeps as the existing entries (Appendix B probing table: Llama L29, Mistral L14, gemma L23), converted with the script's layer/(n_layers-1) convention. **VERIFIED** against the appendix table; not recomputed from the probing archives.

## 2026-08-01: Rebuttal comments, auditor-required fixes applied

- **`rebuttal/revised/00_top_comment.md`**: applied fixes 1, 2, 7 (8 pages / 3 appendices; removed stale "scale (qwen 0.6B - 14B)" from the narrative bullet). Re-opened the full file and confirmed all three edits landed and no other lines changed. **VERIFIED**. Known residual: L42 "and Qwen scale" and L52 (old-submission Qwen-scale appendix) were flagged risky by the auditor but had no required fix, so they stand.
- **`rebuttal/revised/02_reply_UK5t.md`**: applied fixes 3, 6 (8 pages; removed the "scale 60 boundary" claim). Re-opened the full file and confirmed both edits landed. **VERIFIED**. Known residual: L20 "we report the breakdown point rather than hide it" was ruled OVERCLAIM by the auditor but appeared in no required fix; it now also reads inconsistently with the fixed L12. Left unedited per the fix list; needs a decision.
- **`rebuttal/revised/03_reply_APpt.md`**: applied fixes 4, 5 (8 pages / 3 appendices; PCA panels now vector, 311-dpi appendix panels remain). Re-opened the full file and confirmed both edits landed. **VERIFIED**.
- **`rebuttal/revised/01_reply_i7iD.md`**: no required fixes; re-opened in full and confirmed unchanged. **VERIFIED** (unchanged).
- Fix 7's NEW string arrived truncated in the auditor output; the applied edit is the minimal removal its verdict dictates. Not committed, per instructions.

## 2026-08-01 — Cross-coherence pass: reviewer replies vs "New results" top comment
- Waited for mtime stability (all four files unmodified 180s+) before reading; the audit workflow edited `00_top_comment.md` and `03_reply_APpt.md` mid-pass, so I re-waited, re-read all four in full, and re-aligned to the CURRENT anchor (8 pages / 3 appendices).
- **`rebuttal/revised/01_reply_i7iD.md`**: 2 edits ("attention components sit"; pointer to our "New results" comment). Re-opened the full file and confirmed both landed. **VERIFIED**.
- **`rebuttal/revised/02_reply_UK5t.md`**: 3 edits (pointer; "located components sit at similar fractional depth" replacing "mid-depth localization"; restructure line now "8 pages of main text and 3 appendices (geometry, causal localization across models, and steering)" matching the top comment). Re-opened the full file and confirmed all landed. **VERIFIED**.
- **`rebuttal/revised/03_reply_APpt.md`**: 1 edit (pointer). Re-opened the full file and confirmed it landed alongside the audit workflow's W1/W2 updates. **VERIFIED**.
- **`rebuttal/revised/00_top_comment.md`**: read in full as anchor, not edited. Cross-check result: loc layers (gemma L25/42, llama L17/32, mistral L16/32, submission L24/36), 77 of 80, probes >=95% with chance controls, gemma 95% coherence vs ~50%, IFEval ~0.03/~0.05 (consistent with the anchor's "3-5 percentage points"), 4-model list, 5-domain list, 8 pages / 3 appendices all consistent across the four files. **VERIFIED**.
- Note: the task brief stated "9 pages, 2 appendices", but the anchor's CURRENT content says 8 pages / 3 appendices; replies follow the anchor. Not committed, per instructions.

## 2026-08-01 (evening): Audit of POSTED OpenReview comments vs current paper build
Source of truth: `/Users/unrulyabstractions/Downloads/revised.pdf` (full 14-page thread screenshot PDF, read pages 1-14 with image tokens) vs `out/preprint.pdf` (19 pp, built Aug 1 15:13:39, newer than newest source `sections/results.tex` 15:13:27).
- Main text ends on page 8 (conclusion ends top of p8; references pp8-11): **VERIFIED** by reading built PDF pages 8-11 with image tokens.
- 3 appendices (geometry, localization across models, contrastive steering): **VERIFIED** in `main.tex:151-160`.
- Loc layers gemma L25(0.61)/42, llama L17(0.55)/32, mistral L16(0.52)/32, Qwen L24(0.67)/36; early-layer nulls -0.010/-0.026/-0.006: **VERIFIED** in `appendix/localize/localization_across_models.tex:18-22`.
- Probes 95.0/95.8/95.8/96.7 with shuffled 47.4-53.0: **VERIFIED** (`tab:probing-across-models`).
- 77 of 80 = 20+18+20+19: **VERIFIED** (`tab:steering-across-models`, results.tex:116-119).
- IFEval: Qwen -0.034 instr/-0.046 prompt (strict); gemma -0.033/-0.036: **VERIFIED** (`tab:ifeval-steering`). Comment phrasing "~0.05 prompt" slightly generous for gemma (0.036).
- Coherence gemma 95.1% vs Qwen 50.3/50.0: **VERIFIED** (results.tex:93-94).
- "No longer claim a subgraph": **VERIFIED** (grep; "subgraph" only in commented-out abstract lines).
- **BROKEN (posted thread only)**: the POSTED top comment still says "9 pages of main text / 2 appendices (geometry and steering)". Actual paper and the posted APpt + AC comments say 8 pages / 3 appendices. Local `00_top_comment.md` is already correct; the OpenReview post needs the same edit.

## 2026-08-01 (later): Removed Appendix B (causal localization across models), folded into main text
- `appendix/localize/localization_across_models.tex` deleted; its two tables moved into `sections/results.tex` (now Table 3 and Table 4); probe figure dropped (depth figure already carries probe triangles); run-note provenance dropped. All three dangling refs repointed (grep confirms zero refs to the old labels).
- Rebuilt with `bash build.sh`: preprint/review/camera_ready all 18 pages, zero undefined/multiply-defined warnings in `out/preprint.log`, `out/light.pdf` 1.9MB, deployed to public site path.
- **VERIFIED by reading rendered pages with image tokens**: p4 (new sweep-protocol prose), p5 (Table 3 with 5 rows incl. gemma investment; Table 4 probing), p6 (Fig 3 caption now refs Table 3), p8 (main text ends: discussion, limitations, conclusion, acks), p9-12 (references), p13-16 (Appendix A geometry), p17-18 (Appendix B steering, tables B.1-B.5, IFEval cite [58] intact).
- Rebuttal ripple applied to LOCAL files and read back: 00 (2 appendices; localization/probing tables in main text; new "Evidence per model" table), 03 W1 (2 appendices), 04 (2 appendices). 01/02 need no change (no appendix counts).
- Coherence values in the new evidence table (llama 52.4%, mistral 51.0%) come from the verified campaign results (new_results.md v5 / HF); the paper shows them in Figure 5 without printing the two numbers.
- `rebuttal/revised/05_evidence_tables.md` created: 6 tables (overview, localization, probing, steering, IFEval, geometry-collapse). Re-opened in full and checked every row against the built paper's Tables 3/4/5/B.5/A.1 read earlier with image tokens; fixed one transcription error I introduced (Mistral MLP peak L28-L31, had duplicated the gemma investment cell). Coherence column (50.3/52.4/95.1/51.0) from verified campaign results shown in Figure 5. **VERIFIED**.
- `rebuttal/revised/00_top_comment.md`: "Evidence per model" section removed (moved to 05); read back, ends at the Narrative bullets. **VERIFIED**.

## 2026-08-01 (night): 05_evidence_tables.md triple-verified, behavior table added, paper backing edits
- Workflow wf_db93af2a-1a0 (3 agents: paper-match, data-match, internal): 51/56 cells exact vs paper, every number reproduced from raw data (steering summaries, probing metas, loc tarballs re-aggregated, coherence CSV), no wrong digits. Findings fixed: (1) "submission" placeholder in geometry table; (2) all-layer prose contradiction; (3) unbacked "pair-aware 80/20" phrase dropped; (4) coherence column had no backing table in file; (5) IFEval empty leading cells.
- Paper edits: `geometry_across_models.tex` investment row 4{,}588 + caption "The investment row is the submission's own run"; `results.tex` Fig 5 caption adds Llama (52.4%) and Mistral (51.0%). Rebuilt (18pp, 0 warnings, deployed); pages 7 and 14 read with image tokens, both edits VISIBLE. **VERIFIED**.
- New "Geometry vs behavior" section in 05: reasoning/order/label stability extracted via the paper's own metric code; independent verifier agent re-derived ALL five rows from raw responses, every cell matches. Markdown parsed programmatically, all 7 tables structurally valid. **VERIFIED**.
- Known caveat (documented in comment prose): qwen re-run raw responses on HF only; 50.3% rests on coherence_summary.csv. IFEval + gemma-investment loc row remain deck-verified (collaborator raw data never opened) per earlier log entries.
- `new_results.md` bumped to version 6 with the extracted stability table.
- 05_evidence_tables.md restructured dissociation-first per user feedback: new 4-line opener stating the gemma-95-vs-qwen-50 dissociation; "Geometry vs behavior" promoted to section 2 (cross-refs updated: "collapse table at the end", closing line of Geometry section points back); banned punch-line construction replaced. Re-opened lines 1-45 and confirmed structure, all numbers unchanged from the triple-verified version. **VERIFIED**.

## 2026-08-02: Errata verification + inline-fixes comment (06)
- Two agents verified the advisor's 6 candidate errata against the SUBMITTED source (paper/out/submission.zip, letter map derived from main.tex input order). CONFIRMED: G.1 "+52.3pp" (should be +49.2, contrastive_probing_linear.tex:22); U.2 probe-coefficient vs AB.1 difference-in-means CAA definitions (notation.tex glossary sides with AB.1; propagates to main §3 and Appendix S). NEW REAL erratum found: frontmatter Index of Appendices letters off by one after H. REFUTED (kept OUT of the comment): L18 "contradiction" (different aggregation regimes, K.3 vs K.5), 71 vs 57+10 (4 mixed pairs accounted, D.3:49), "45 strong pairs" (does not exist; 45 = steering configs S.1.1), "redundant vs AND-like" captions (consistent).
- Figure 4 identified (results.tex:46, four change_of_turn PNGs each rendered at ~1.3in) and all four panels READ with image tokens by the agent; comment table describes them qualitatively (no invented numerics; the local dataset_projs npz turned out to be a different 100-sample run, AUC check confirmed it does not reproduce the figure, so it was NOT used).
- 06_reply_APpt_inline_fixes.md written (inline primitives, dataset table, Fig-4-as-table, committed outline from the verified 18pp build, 3 verified errata). IFEval phrasing unified across 00/01/02/04 earlier (grep-verified).
- Fleet: reap.sh Gate 2 REFUSED teardown (no pull manifest) — 11 boxes still up, capture-sweep agent running; NO destroys performed.
- Figure 3 regenerated (make_depth_figure.py rewritten): rows ordered by model size (0.6B top to 14B bottom, size-tier gaps), EVERY row now labeled "Name (theme)" with theme in italic DejaVu Sans #3b7f7a vs serif muted names; themes: investment for all Qwen rows, health/education/climate/investment for the families, classification/minimally-framed kept on the target's extra rows. IQR unchanged 0.61-0.69, 15 rows. Caption updated (ordered by size, theme note, "indented" wording removed). Rebuilt 18pp 0 warnings, deployed; page 6 read with image tokens, figure and caption VERIFIED visually.

## 2026-08-01 (late night): Revision ported to canonical repo ~/work/papers/paper
- Canonical repo identified (other session's bib/arXiv commits on main; no revision content). Revision ported on NEW branch neurips-revision (main untouched): rsync of the OLD tree (143 paths) + rebuttal/ restored from the Trash rescue (left uncommitted). Commit 19433ec.
- Built all three variants with the repo's build.sh: preprint 19 pages, 0 undefined/multiply-defined, deployed to the public site path. Pages 13-19 read with image tokens: Appendix A now carries fan figures A.5-A.8 (llama/gemma/mistral/qwen-startup), all rendering with legible vector labels; Appendix B steering pp18-19 intact. **VERIFIED**.
- 06_reply outline rows corrected to the built reality (sections 6-8 on p8; appendices 13-19; total 19 < 25).
- Known follow-ups: (a) the branch's references.bib is the revision's own; the other session's 3 rounds of bib fixes live on main and are NOT yet merged into the branch bib; (b) og-qwen investment fan queued (agent building fan_qwen3_4b_investment.pdf); (c) experiment-repo clean/HF-sync/push agent running.
- Investment fan added as Figure A.5 (4,588 samples, 2,083 Long / 2,505 Short, 12 stored layers, four chat-suffix panels). Rebuilt: 19pp, 0 warnings, deployed. Pages 15-17 read with image tokens: A.5 on p16, campaign fans A.6-A.9 on p17, all legible. 06 outline spans unchanged (13-19). **VERIFIED**.
